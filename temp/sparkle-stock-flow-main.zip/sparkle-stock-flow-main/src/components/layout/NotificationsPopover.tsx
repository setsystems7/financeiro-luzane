import { Bell, Package, TrendingDown, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useLowStockProducts } from '@/hooks/useStock';

interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'warning' | 'info' | 'alert';
  time: string;
}

export function NotificationsPopover() {
  const { data: lowStockProducts } = useLowStockProducts();

  // Generate notifications from low stock products
  const notifications: Notification[] = (lowStockProducts || []).slice(0, 5).map((product) => ({
    id: product.id,
    title: 'Estoque Baixo',
    message: `${product.name} está com estoque baixo`,
    type: 'warning' as const,
    time: 'Agora',
  }));

  // Add some static notifications if no low stock
  if (notifications.length === 0) {
    notifications.push(
      {
        id: '1',
        title: 'Sistema Atualizado',
        message: 'Novas funcionalidades disponíveis',
        type: 'info',
        time: 'Hoje',
      },
      {
        id: '2',
        title: 'Bem-vindo!',
        message: 'Seu sistema está pronto para uso',
        type: 'info',
        time: 'Hoje',
      }
    );
  }

  const getIcon = (type: string) => {
    switch (type) {
      case 'warning':
        return <Package className="w-4 h-4 text-amber-500" />;
      case 'alert':
        return <AlertTriangle className="w-4 h-4 text-destructive" />;
      default:
        return <TrendingDown className="w-4 h-4 text-primary" />;
    }
  };

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative hover-pop">
          <Bell className="w-5 h-5" />
          {notifications.length > 0 && (
            <Badge 
              variant="pink" 
              className="absolute -top-1 -right-1 w-5 h-5 p-0 flex items-center justify-center text-[10px] animate-pulse-soft"
            >
              {notifications.length}
            </Badge>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-0" align="end">
        <div className="p-4 border-b border-border">
          <h4 className="font-semibold text-foreground">Notificações</h4>
          <p className="text-xs text-muted-foreground">
            Você tem {notifications.length} notificações
          </p>
        </div>
        <ScrollArea className="h-[300px]">
          <div className="p-2">
            {notifications.length === 0 ? (
              <div className="p-4 text-center text-muted-foreground text-sm">
                Nenhuma notificação
              </div>
            ) : (
              notifications.map((notification) => (
                <div
                  key={notification.id}
                  className="flex items-start gap-3 p-3 rounded-lg hover:bg-muted/50 transition-colors cursor-pointer"
                >
                  <div className="mt-0.5 p-2 rounded-full bg-muted">
                    {getIcon(notification.type)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground">
                      {notification.title}
                    </p>
                    <p className="text-xs text-muted-foreground truncate">
                      {notification.message}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {notification.time}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        </ScrollArea>
      </PopoverContent>
    </Popover>
  );
}
