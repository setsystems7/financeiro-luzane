import { ThemeToggle } from '@/components/ui/theme-toggle';
import { NotificationsPopover } from './NotificationsPopover';
import { UserProfilePopover } from './UserProfilePopover';

interface HeaderProps {
  title: string;
  subtitle?: string;
}

export function Header({ title, subtitle }: HeaderProps) {
  return (
    <header className="h-16 border-b border-border bg-card px-4 md:px-6 flex items-center justify-between transition-colors duration-300">
      <div className="min-w-0 flex-1">
        <h1 className="text-lg md:text-xl font-semibold text-foreground truncate">{title}</h1>
        {subtitle && (
          <p className="text-xs md:text-sm text-muted-foreground truncate">{subtitle}</p>
        )}
      </div>

      <div className="flex items-center gap-2 md:gap-3 shrink-0">
        <ThemeToggle />
        <NotificationsPopover />
        <UserProfilePopover />
      </div>
    </header>
  );
}
