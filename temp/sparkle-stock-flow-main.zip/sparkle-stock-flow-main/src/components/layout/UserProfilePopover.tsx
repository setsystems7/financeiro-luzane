import { User, LogOut, Settings, Mail } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Separator } from '@/components/ui/separator';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';

export function UserProfilePopover() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    try {
      await signOut();
      toast.success('Logout realizado com sucesso!');
      navigate('/auth');
    } catch (error) {
      toast.error('Erro ao fazer logout');
    }
  };

  const userEmail = user?.email || 'usuário@email.com';
  const userName = user?.user_metadata?.full_name || userEmail.split('@')[0];

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="rounded-full hover-pop">
          <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center transition-transform duration-200 hover:scale-105">
            <User className="w-4 h-4 text-primary-foreground" />
          </div>
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-72 p-0" align="end">
        <div className="p-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-primary flex items-center justify-center">
              <User className="w-6 h-6 text-primary-foreground" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-foreground truncate capitalize">
                {userName}
              </p>
              <p className="text-xs text-muted-foreground truncate">
                {userEmail}
              </p>
            </div>
          </div>
        </div>
        
        <Separator />
        
        <div className="p-2">
          <button
            className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-muted/50 transition-colors text-left"
            onClick={() => navigate('/settings')}
          >
            <Settings className="w-4 h-4 text-muted-foreground" />
            <span className="text-sm text-foreground">Configurações</span>
          </button>
          
          <button
            className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-muted/50 transition-colors text-left"
          >
            <Mail className="w-4 h-4 text-muted-foreground" />
            <span className="text-sm text-foreground">Suporte</span>
          </button>
        </div>
        
        <Separator />
        
        <div className="p-2">
          <button
            onClick={handleSignOut}
            className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-destructive/10 transition-colors text-left group"
          >
            <LogOut className="w-4 h-4 text-destructive" />
            <span className="text-sm text-destructive">Sair da conta</span>
          </button>
        </div>
      </PopoverContent>
    </Popover>
  );
}
