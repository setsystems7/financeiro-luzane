import * as React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { ABCXYZSummary } from '@/hooks/useABCXYZAnalysis';

interface ABCPieChartProps {
  summary: ABCXYZSummary;
}

const COLORS = {
  A: 'hsl(var(--success))',
  B: 'hsl(var(--warning))',
  C: 'hsl(var(--destructive))',
};

export function ABCPieChart({ summary }: ABCPieChartProps) {
  const data = [
    { 
      name: 'Classe A', 
      value: summary.classA.count, 
      revenue: summary.classA.revenue,
      percentage: summary.classA.percentage,
      class: 'A' 
    },
    { 
      name: 'Classe B', 
      value: summary.classB.count, 
      revenue: summary.classB.revenue,
      percentage: summary.classB.percentage,
      class: 'B' 
    },
    { 
      name: 'Classe C', 
      value: summary.classC.count, 
      revenue: summary.classC.revenue,
      percentage: summary.classC.percentage,
      class: 'C' 
    },
  ];

  const CustomTooltip = React.forwardRef<HTMLDivElement, any>(({ active, payload }, ref) => {
    if (active && payload && payload.length) {
      const item = payload[0].payload;
      return (
        <div ref={ref} className="bg-popover border border-border rounded-lg p-3 shadow-lg">
          <p className="font-semibold">{item.name}</p>
          <p className="text-sm text-muted-foreground">
            {item.value} produtos
          </p>
          <p className="text-sm text-muted-foreground">
            R$ {item.revenue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
          </p>
          <p className="text-sm font-medium text-primary">
            {item.percentage.toFixed(1)}% do faturamento
          </p>
        </div>
      );
    }
    return null;
  });

  const renderCustomLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent, name }: any) => {
    const RADIAN = Math.PI / 180;
    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);

    if (percent < 0.05) return null;

    return (
      <text
        x={x}
        y={y}
        fill="white"
        textAnchor="middle"
        dominantBaseline="central"
        className="text-xs font-semibold"
      >
        {name.split(' ')[1]}
      </text>
    );
  };

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base">Curva ABC - Distribuição</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[250px]">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={renderCustomLabel}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {data.map((entry, index) => (
                  <Cell 
                    key={`cell-${index}`} 
                    fill={COLORS[entry.class as keyof typeof COLORS]} 
                  />
                ))}
              </Pie>
              <Tooltip content={<CustomTooltip />} />
              <Legend 
                formatter={(value, entry: any) => {
                  const item = data.find(d => d.name === value);
                  return (
                    <span className="text-sm">
                      {value} ({item?.value} - {item?.percentage.toFixed(0)}%)
                    </span>
                  );
                }}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="grid grid-cols-3 gap-2 mt-4 text-center">
          <div className="p-2 rounded-lg bg-success/10">
            <p className="text-xs text-muted-foreground">Classe A</p>
            <p className="font-bold text-success">{summary.classA.count}</p>
            <p className="text-xs">~80% faturamento</p>
          </div>
          <div className="p-2 rounded-lg bg-warning/10">
            <p className="text-xs text-muted-foreground">Classe B</p>
            <p className="font-bold text-warning">{summary.classB.count}</p>
            <p className="text-xs">~15% faturamento</p>
          </div>
          <div className="p-2 rounded-lg bg-destructive/10">
            <p className="text-xs text-muted-foreground">Classe C</p>
            <p className="font-bold text-destructive">{summary.classC.count}</p>
            <p className="text-xs">~5% faturamento</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
