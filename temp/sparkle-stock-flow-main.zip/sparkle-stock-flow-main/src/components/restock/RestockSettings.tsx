import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Save, Settings } from 'lucide-react';

export function RestockSettings() {
  const queryClient = useQueryClient();

  const { data: suppliers } = useQuery({
    queryKey: ['suppliers-settings'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('suppliers')
        .select('id, name, default_lead_time_days, order_cost, min_order_value, reliability_score')
        .order('name');
      if (error) throw error;
      return data;
    },
  });

  const updateSupplier = useMutation({
    mutationFn: async (data: {
      id: string;
      default_lead_time_days: number;
      order_cost: number;
      min_order_value: number;
      reliability_score: number;
    }) => {
      const { error } = await supabase
        .from('suppliers')
        .update({
          default_lead_time_days: data.default_lead_time_days,
          order_cost: data.order_cost,
          min_order_value: data.min_order_value,
          reliability_score: data.reliability_score,
        })
        .eq('id', data.id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['suppliers-settings'] });
      queryClient.invalidateQueries({ queryKey: ['restock-calculations'] });
      toast.success('Fornecedor atualizado');
    },
    onError: () => {
      toast.error('Erro ao atualizar fornecedor');
    },
  });

  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValues, setEditValues] = useState<Record<string, any>>({});

  const startEdit = (supplier: any) => {
    setEditingId(supplier.id);
    setEditValues({
      default_lead_time_days: supplier.default_lead_time_days ?? 7,
      order_cost: supplier.order_cost ?? 50,
      min_order_value: supplier.min_order_value ?? 0,
      reliability_score: supplier.reliability_score ?? 100,
    });
  };

  const saveEdit = () => {
    if (editingId && editValues) {
      updateSupplier.mutate({
        id: editingId,
        default_lead_time_days: editValues.default_lead_time_days ?? 7,
        order_cost: editValues.order_cost ?? 50,
        min_order_value: editValues.min_order_value ?? 0,
        reliability_score: editValues.reliability_score ?? 100,
      });
      setEditingId(null);
    }
  };

  const [serviceLevel, setServiceLevel] = useState('95');
  const [holdingCost, setHoldingCost] = useState('2');
  const [excessDays, setExcessDays] = useState('90');

  return (
    <div className="space-y-6">
      {/* General Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Settings className="w-4 h-4" />
            Configurações Gerais
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <Label>Nível de Serviço Desejado</Label>
              <Select value={serviceLevel} onValueChange={setServiceLevel}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="90">90% (Z = 1.28)</SelectItem>
                  <SelectItem value="95">95% (Z = 1.65)</SelectItem>
                  <SelectItem value="99">99% (Z = 2.33)</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                Maior nível = mais estoque de segurança
              </p>
            </div>

            <div className="space-y-2">
              <Label>Custo de Manutenção (% a.m.)</Label>
              <Input
                type="number"
                value={holdingCost}
                onChange={e => setHoldingCost(e.target.value)}
                step="0.5"
                min="0"
              />
              <p className="text-xs text-muted-foreground">
                Usado no cálculo do lote econômico
              </p>
            </div>

            <div className="space-y-2">
              <Label>Dias para Estoque Excessivo</Label>
              <Input
                type="number"
                value={excessDays}
                onChange={e => setExcessDays(e.target.value)}
                min="30"
              />
              <p className="text-xs text-muted-foreground">
                Cobertura acima disso = capital parado
              </p>
            </div>
          </div>

          <Button className="mt-4">
            <Save className="w-4 h-4 mr-2" />
            Salvar Configurações
          </Button>
        </CardContent>
      </Card>

      {/* Supplier Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Configurações por Fornecedor</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Fornecedor</TableHead>
                  <TableHead className="text-center">Lead Time (dias)</TableHead>
                  <TableHead className="text-center">Custo do Pedido (R$)</TableHead>
                  <TableHead className="text-center">Pedido Mínimo (R$)</TableHead>
                  <TableHead className="text-center">Confiabilidade (%)</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {suppliers?.map(supplier => (
                  <TableRow key={supplier.id}>
                    <TableCell className="font-medium">{supplier.name}</TableCell>
                    
                    {editingId === supplier.id ? (
                      <>
                        <TableCell className="text-center">
                          <Input
                            type="number"
                            value={editValues.default_lead_time_days}
                            onChange={e => setEditValues(prev => ({ ...prev, default_lead_time_days: Number(e.target.value) }))}
                            className="w-20 mx-auto text-center"
                            min={1}
                          />
                        </TableCell>
                        <TableCell className="text-center">
                          <Input
                            type="number"
                            value={editValues.order_cost}
                            onChange={e => setEditValues(prev => ({ ...prev, order_cost: Number(e.target.value) }))}
                            className="w-24 mx-auto text-center"
                            min={0}
                          />
                        </TableCell>
                        <TableCell className="text-center">
                          <Input
                            type="number"
                            value={editValues.min_order_value}
                            onChange={e => setEditValues(prev => ({ ...prev, min_order_value: Number(e.target.value) }))}
                            className="w-24 mx-auto text-center"
                            min={0}
                          />
                        </TableCell>
                        <TableCell className="text-center">
                          <Input
                            type="number"
                            value={editValues.reliability_score}
                            onChange={e => setEditValues(prev => ({ ...prev, reliability_score: Number(e.target.value) }))}
                            className="w-20 mx-auto text-center"
                            min={0}
                            max={100}
                          />
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-1">
                            <Button size="sm" onClick={saveEdit}>
                              <Save className="w-3 h-3" />
                            </Button>
                            <Button size="sm" variant="ghost" onClick={() => setEditingId(null)}>
                              Cancelar
                            </Button>
                          </div>
                        </TableCell>
                      </>
                    ) : (
                      <>
                        <TableCell className="text-center">{supplier.default_lead_time_days || 7}</TableCell>
                        <TableCell className="text-center">R$ {(supplier.order_cost || 50).toFixed(2)}</TableCell>
                        <TableCell className="text-center">R$ {(supplier.min_order_value || 0).toFixed(2)}</TableCell>
                        <TableCell className="text-center">{supplier.reliability_score || 100}%</TableCell>
                        <TableCell>
                          <Button size="sm" variant="ghost" onClick={() => startEdit(supplier)}>
                            Editar
                          </Button>
                        </TableCell>
                      </>
                    )}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {!suppliers?.length && (
            <p className="text-center text-muted-foreground py-8">
              Nenhum fornecedor cadastrado
            </p>
          )}
        </CardContent>
      </Card>

      {/* Info Card */}
      <Card>
        <CardContent className="p-4">
          <h4 className="font-semibold mb-2">Sobre os Cálculos</h4>
          <div className="text-sm text-muted-foreground space-y-2">
            <p>
              <strong>Ponto de Reposição</strong> = (Demanda Diária × Lead Time) + Estoque de Segurança
            </p>
            <p>
              <strong>Estoque de Segurança</strong> = Z × σ × √Lead Time (onde Z depende do nível de serviço)
            </p>
            <p>
              <strong>Lote Econômico (EOQ)</strong> = √(2 × Demanda Anual × Custo do Pedido / Custo de Manutenção)
            </p>
            <p>
              <strong>Curva ABC</strong>: A (80% faturamento), B (15%), C (5%)
            </p>
            <p>
              <strong>Curva XYZ</strong>: X (CV ≤20%), Y (20-50%), Z ({'>'} 50%) baseado na variabilidade da demanda
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
