import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine, Area, AreaChart } from 'recharts';
import { RestockProduct } from '@/hooks/useRestockCalculations';
import { Calculator, TrendingUp, AlertTriangle, DollarSign } from 'lucide-react';

interface RestockSimulatorProps {
  products: RestockProduct[];
}

export function RestockSimulator({ products }: RestockSimulatorProps) {
  const [selectedProductId, setSelectedProductId] = useState<string>('');
  const [purchaseQuantity, setPurchaseQuantity] = useState<number>(0);
  const [newLeadTime, setNewLeadTime] = useState<number>(7);
  const [demandChange, setDemandChange] = useState<number>(0);

  const selectedProduct = products.find(p => p.productId === selectedProductId);

  const generateProjection = () => {
    if (!selectedProduct) return [];

    const days = 90;
    const data = [];
    let stock = selectedProduct.currentStock;
    const dailyDemand = selectedProduct.dailyDemand * (1 + demandChange / 100);
    
    // Current scenario
    const currentData = [];
    let currentStock = selectedProduct.currentStock;
    
    for (let i = 0; i <= days; i++) {
      currentData.push({
        day: i,
        current: Math.max(0, currentStock),
      });
      currentStock -= selectedProduct.dailyDemand;
    }

    // Simulated scenario
    let simulatedStock = selectedProduct.currentStock + purchaseQuantity;
    
    for (let i = 0; i <= days; i++) {
      if (!data[i]) {
        data[i] = { day: i, current: currentData[i]?.current || 0 };
      }
      data[i].simulated = Math.max(0, simulatedStock);
      data[i].reorderPoint = selectedProduct.reorderPoint;
      data[i].safetyStock = selectedProduct.safetyStock;
      simulatedStock -= dailyDemand;
    }

    return data;
  };

  const projectionData = generateProjection();

  const calculateMetrics = () => {
    if (!selectedProduct) return null;

    const dailyDemand = selectedProduct.dailyDemand * (1 + demandChange / 100);
    const newStock = selectedProduct.currentStock + purchaseQuantity;
    const newCoverage = dailyDemand > 0 ? newStock / dailyDemand : 999;
    const investmentCost = purchaseQuantity * selectedProduct.costPrice;
    const potentialRevenue = purchaseQuantity * selectedProduct.salePrice;
    const potentialProfit = potentialRevenue - investmentCost;

    return {
      currentCoverage: selectedProduct.daysOfCoverage,
      newCoverage,
      investmentCost,
      potentialRevenue,
      potentialProfit,
      newDaysUntilStockout: dailyDemand > 0 ? Math.round(newStock / dailyDemand) : null,
      riskLevel: newCoverage < 7 ? 'high' : newCoverage < 14 ? 'medium' : 'low',
    };
  };

  const metrics = calculateMetrics();

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Configuration Panel */}
      <Card className="lg:col-span-1">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Calculator className="w-4 h-4" />
            Parâmetros da Simulação
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label>Produto</Label>
            <Select value={selectedProductId} onValueChange={setSelectedProductId}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione um produto" />
              </SelectTrigger>
              <SelectContent>
                {products.slice(0, 50).map(product => (
                  <SelectItem key={product.productId} value={product.productId}>
                    {product.productName}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {selectedProduct && (
            <>
              <div className="p-3 rounded-lg bg-muted text-sm space-y-1">
                <p><strong>Estoque atual:</strong> {selectedProduct.currentStock} un</p>
                <p><strong>Demanda diária:</strong> {selectedProduct.dailyDemand.toFixed(1)} un</p>
                <p><strong>Lead time:</strong> {selectedProduct.leadTimeDays} dias</p>
                <p><strong>Ponto de reposição:</strong> {selectedProduct.reorderPoint} un</p>
              </div>

              <div className="space-y-2">
                <Label>Quantidade a comprar</Label>
                <Input
                  type="number"
                  value={purchaseQuantity}
                  onChange={e => setPurchaseQuantity(Number(e.target.value))}
                  min={0}
                />
                {selectedProduct.suggestedQuantity > 0 && (
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="w-full"
                    onClick={() => setPurchaseQuantity(selectedProduct.suggestedQuantity)}
                  >
                    Usar sugestão: {selectedProduct.suggestedQuantity} un
                  </Button>
                )}
              </div>

              <div className="space-y-2">
                <Label>Novo lead time (dias)</Label>
                <Input
                  type="number"
                  value={newLeadTime}
                  onChange={e => setNewLeadTime(Number(e.target.value))}
                  min={1}
                />
              </div>

              <div className="space-y-2">
                <Label>Variação de demanda: {demandChange > 0 ? '+' : ''}{demandChange}%</Label>
                <Slider
                  value={[demandChange]}
                  onValueChange={([v]) => setDemandChange(v)}
                  min={-50}
                  max={50}
                  step={5}
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>-50%</span>
                  <span>0%</span>
                  <span>+50%</span>
                </div>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* Results Panel */}
      <Card className="lg:col-span-2">
        <CardHeader>
          <CardTitle className="text-base">Projeção de Estoque (90 dias)</CardTitle>
        </CardHeader>
        <CardContent>
          {selectedProduct ? (
            <>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={projectionData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis 
                      dataKey="day" 
                      tick={{ fontSize: 10 }}
                      label={{ value: 'Dias', position: 'bottom', fontSize: 12 }}
                    />
                    <YAxis 
                      tick={{ fontSize: 10 }}
                      label={{ value: 'Unidades', angle: -90, position: 'insideLeft', fontSize: 12 }}
                    />
                    <Tooltip 
                      contentStyle={{
                        backgroundColor: 'hsl(var(--popover))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px',
                      }}
                      formatter={(value: number, name: string) => [
                        Math.round(value),
                        name === 'current' ? 'Cenário Atual' : 
                        name === 'simulated' ? 'Com Compra' :
                        name === 'reorderPoint' ? 'Ponto Reposição' : 'Estoque Segurança'
                      ]}
                    />
                    <ReferenceLine 
                      y={selectedProduct.reorderPoint} 
                      stroke="hsl(var(--warning))" 
                      strokeDasharray="5 5"
                    />
                    <ReferenceLine 
                      y={selectedProduct.safetyStock} 
                      stroke="hsl(var(--destructive))" 
                      strokeDasharray="5 5"
                    />
                    <Area
                      type="monotone"
                      dataKey="current"
                      stroke="hsl(var(--muted-foreground))"
                      fill="hsl(var(--muted))"
                      fillOpacity={0.3}
                      strokeWidth={2}
                    />
                    {purchaseQuantity > 0 && (
                      <Area
                        type="monotone"
                        dataKey="simulated"
                        stroke="hsl(var(--primary))"
                        fill="hsl(var(--primary))"
                        fillOpacity={0.3}
                        strokeWidth={2}
                      />
                    )}
                  </AreaChart>
                </ResponsiveContainer>
              </div>

              {metrics && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
                  <div className="p-3 rounded-lg bg-muted">
                    <p className="text-xs text-muted-foreground">Cobertura Atual</p>
                    <p className="text-lg font-bold">{Math.round(metrics.currentCoverage)} dias</p>
                  </div>
                  <div className="p-3 rounded-lg bg-primary/10">
                    <p className="text-xs text-muted-foreground">Nova Cobertura</p>
                    <p className="text-lg font-bold text-primary">{Math.round(metrics.newCoverage)} dias</p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted">
                    <div className="flex items-center gap-1">
                      <DollarSign className="w-3 h-3 text-muted-foreground" />
                      <p className="text-xs text-muted-foreground">Investimento</p>
                    </div>
                    <p className="text-lg font-bold">
                      R$ {metrics.investmentCost.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </p>
                  </div>
                  <div className="p-3 rounded-lg bg-success/10">
                    <div className="flex items-center gap-1">
                      <TrendingUp className="w-3 h-3 text-success" />
                      <p className="text-xs text-muted-foreground">Lucro Potencial</p>
                    </div>
                    <p className="text-lg font-bold text-success">
                      R$ {metrics.potentialProfit.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </p>
                  </div>
                </div>
              )}
            </>
          ) : (
            <div className="flex flex-col items-center justify-center h-[300px] text-muted-foreground">
              <Calculator className="w-12 h-12 mb-4" />
              <p>Selecione um produto para simular</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
