import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { SupplierGroup, PurchaseItem } from '@/hooks/usePurchaseSuggestions';
import { cn } from '@/lib/utils';
import { ChevronDown, ChevronUp, Download, Check, Truck, Package } from 'lucide-react';
import { toast } from 'sonner';

interface PurchaseListProps {
  groups: SupplierGroup[];
  totalCost: number;
  totalItems: number;
}

export function PurchaseList({ groups, totalCost, totalItems }: PurchaseListProps) {
  const [openGroups, setOpenGroups] = useState<Set<string | null>>(new Set(groups.map(g => g.supplierId)));
  const [selectedItems, setSelectedItems] = useState<Set<string>>(new Set());
  const [quantities, setQuantities] = useState<Record<string, number>>({});

  const toggleGroup = (supplierId: string | null) => {
    const newOpen = new Set(openGroups);
    if (newOpen.has(supplierId)) {
      newOpen.delete(supplierId);
    } else {
      newOpen.add(supplierId);
    }
    setOpenGroups(newOpen);
  };

  const toggleItem = (productId: string) => {
    const newSelected = new Set(selectedItems);
    if (newSelected.has(productId)) {
      newSelected.delete(productId);
    } else {
      newSelected.add(productId);
    }
    setSelectedItems(newSelected);
  };

  const updateQuantity = (productId: string, quantity: number) => {
    setQuantities(prev => ({ ...prev, [productId]: quantity }));
  };

  const getItemCost = (item: PurchaseItem) => {
    const qty = quantities[item.productId] ?? item.suggestedQuantity;
    return qty * item.unitCost;
  };

  const getSelectedTotal = () => {
    let total = 0;
    groups.forEach(group => {
      group.items.forEach(item => {
        if (selectedItems.has(item.productId)) {
          total += getItemCost(item);
        }
      });
    });
    return total;
  };

  const exportToExcel = () => {
    // Create CSV content
    let csv = 'Fornecedor,Produto,Estoque Atual,Quantidade Sugerida,Custo Unit.,Custo Total,Urgência\n';
    
    groups.forEach(group => {
      group.items.forEach(item => {
        if (selectedItems.has(item.productId) || selectedItems.size === 0) {
          const qty = quantities[item.productId] ?? item.suggestedQuantity;
          csv += `"${group.supplierName}","${item.productName}",${item.currentStock},${qty},${item.unitCost.toFixed(2)},${(qty * item.unitCost).toFixed(2)},${item.urgency}\n`;
        }
      });
    });

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `lista-compras-${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    toast.success('Lista exportada com sucesso!');
  };

  const urgencyColors = {
    critical: 'bg-destructive text-destructive-foreground',
    high: 'bg-warning text-warning-foreground',
    medium: 'bg-primary text-primary-foreground',
    low: 'bg-muted text-muted-foreground',
  };

  return (
    <div className="space-y-4">
      {/* Summary Header */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-6">
              <div>
                <p className="text-sm text-muted-foreground">Itens selecionados</p>
                <p className="text-xl font-bold">{selectedItems.size || totalItems}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Custo Total</p>
                <p className="text-xl font-bold text-primary">
                  R$ {(selectedItems.size > 0 ? getSelectedTotal() : totalCost).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={exportToExcel}>
                <Download className="w-4 h-4 mr-2" />
                Exportar Excel
              </Button>
              <Button>
                <Check className="w-4 h-4 mr-2" />
                Marcar como Pedido
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Supplier Groups */}
      {groups.map(group => (
        <Card key={group.supplierId ?? 'no-supplier'}>
          <Collapsible open={openGroups.has(group.supplierId)}>
            <CollapsibleTrigger asChild>
              <CardHeader 
                className="cursor-pointer hover:bg-muted/50 transition-colors"
                onClick={() => toggleGroup(group.supplierId)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Truck className="w-5 h-5 text-muted-foreground" />
                    <div>
                      <CardTitle className="text-base">{group.supplierName}</CardTitle>
                      <p className="text-sm text-muted-foreground">
                        {group.itemCount} produtos • Lead time: {group.leadTimeDays} dias
                        {group.minOrderValue > 0 && ` • Pedido mín: R$ ${group.minOrderValue}`}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <p className="font-semibold">
                        R$ {group.totalCost.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </p>
                    </div>
                    {openGroups.has(group.supplierId) ? (
                      <ChevronUp className="w-5 h-5" />
                    ) : (
                      <ChevronDown className="w-5 h-5" />
                    )}
                  </div>
                </div>
              </CardHeader>
            </CollapsibleTrigger>
            
            <CollapsibleContent>
              <CardContent className="pt-0">
                <div className="space-y-2">
                  {group.items.map(item => (
                    <div 
                      key={item.productId}
                      className={cn(
                        "flex items-center gap-4 p-3 rounded-lg border",
                        selectedItems.has(item.productId) && "bg-primary/5 border-primary"
                      )}
                    >
                      <Checkbox
                        checked={selectedItems.has(item.productId)}
                        onCheckedChange={() => toggleItem(item.productId)}
                      />
                      
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{item.productName}</p>
                        <p className="text-xs text-muted-foreground">
                          Estoque: {item.currentStock} • 
                          {item.daysUntilStockout !== null 
                            ? ` Ruptura em ${item.daysUntilStockout} dias`
                            : ' Sem demanda'}
                        </p>
                      </div>

                      <Badge className={cn("shrink-0", urgencyColors[item.urgency])}>
                        {item.urgency === 'critical' && 'Crítico'}
                        {item.urgency === 'high' && 'Alto'}
                        {item.urgency === 'medium' && 'Médio'}
                        {item.urgency === 'low' && 'Baixo'}
                      </Badge>

                      <div className="flex items-center gap-2">
                        <Input
                          type="number"
                          value={quantities[item.productId] ?? item.suggestedQuantity}
                          onChange={e => updateQuantity(item.productId, Number(e.target.value))}
                          className="w-20 text-center"
                          min={1}
                        />
                        <span className="text-sm text-muted-foreground">un</span>
                      </div>

                      <div className="text-right w-24">
                        <p className="font-semibold">
                          R$ {getItemCost(item).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          R$ {item.unitCost.toFixed(2)}/un
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </CollapsibleContent>
          </Collapsible>
        </Card>
      ))}

      {groups.length === 0 && (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Package className="w-12 h-12 text-muted-foreground mb-4" />
            <p className="text-lg font-medium">Nenhuma sugestão de compra</p>
            <p className="text-muted-foreground">
              Todos os produtos estão com estoque adequado
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
