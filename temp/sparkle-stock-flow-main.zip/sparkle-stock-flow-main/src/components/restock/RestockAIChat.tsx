import { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { useRestockAI, AIMessage, RestockContext } from '@/hooks/useRestockAI';
import { cn } from '@/lib/utils';
import { 
  Bot, 
  User, 
  Send, 
  Sparkles, 
  Trash2, 
  Loader2, 
  RefreshCw, 
  X,
  AlertCircle,
  MessageSquare,
  Lightbulb,
  Zap
} from 'lucide-react';

interface RestockAIChatProps {
  context?: RestockContext;
  className?: string;
}

export function RestockAIChat({ context, className }: RestockAIChatProps) {
  const { 
    messages, 
    isLoading, 
    error,
    sendMessage, 
    clearMessages, 
    cancelRequest,
    retryLastMessage,
    quickQuestions 
  } = useRestockAI();
  
  const [input, setInput] = useState('');
  const [showQuickQuestions, setShowQuickQuestions] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Auto-scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      const scrollContainer = scrollRef.current.querySelector('[data-radix-scroll-area-viewport]');
      if (scrollContainer) {
        scrollContainer.scrollTop = scrollContainer.scrollHeight;
      }
    }
  }, [messages, isLoading]);

  // Focus input after sending
  useEffect(() => {
    if (!isLoading && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isLoading]);

  const handleSend = useCallback(async () => {
    if (!input.trim() || isLoading) return;
    const message = input;
    setInput('');
    setShowQuickQuestions(false);
    await sendMessage(message, context);
  }, [input, isLoading, sendMessage, context]);

  const handleQuickQuestion = useCallback(async (question: string) => {
    if (isLoading) return;
    setShowQuickQuestions(false);
    await sendMessage(question, context);
  }, [isLoading, sendMessage, context]);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }, [handleSend]);

  const handleRetry = useCallback(async () => {
    await retryLastMessage(context);
  }, [retryLastMessage, context]);

  const formatMessage = (content: string) => {
    const lines = content.split('\n');
    const elements: JSX.Element[] = [];
    let inTable = false;
    let tableRows: string[] = [];

    const processLine = (line: string, key: number): JSX.Element | null => {
      // Table detection
      if (line.includes('|') && line.trim().startsWith('|')) {
        if (!inTable) {
          inTable = true;
          tableRows = [];
        }
        tableRows.push(line);
        return null;
      } else if (inTable) {
        // End of table
        inTable = false;
        const tableElement = renderTable(tableRows, key);
        tableRows = [];
        return tableElement;
      }

      // Headers
      if (line.startsWith('###')) {
        return <h4 key={key} className="font-semibold mt-4 mb-2 text-sm">{line.replace(/^###\s*/, '')}</h4>;
      }
      if (line.startsWith('##')) {
        return <h3 key={key} className="font-bold mt-4 mb-2">{line.replace(/^##\s*/, '')}</h3>;
      }
      if (line.startsWith('#')) {
        return <h2 key={key} className="font-bold text-lg mt-4 mb-2">{line.replace(/^#\s*/, '')}</h2>;
      }

      // Process inline formatting
      let processedLine = line;
      
      // Bold
      processedLine = processedLine.replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold">$1</strong>');
      
      // Italic
      processedLine = processedLine.replace(/\*(.*?)\*/g, '<em>$1</em>');
      
      // Code
      processedLine = processedLine.replace(/`(.*?)`/g, '<code class="bg-muted px-1 py-0.5 rounded text-xs">$1</code>');

      // List items
      if (line.startsWith('- ') || line.startsWith('* ')) {
        return (
          <li key={key} className="ml-4 list-disc text-sm" dangerouslySetInnerHTML={{ __html: processedLine.slice(2) }} />
        );
      }
      if (line.match(/^\d+\.\s/)) {
        return (
          <li key={key} className="ml-4 list-decimal text-sm" dangerouslySetInnerHTML={{ __html: processedLine.replace(/^\d+\.\s/, '') }} />
        );
      }

      // Emoji-started lines (like alerts)
      if (/^[⚠️💰📉🔥❌⏱️⏳💳🔧👉💡✅🎯📊]/.test(line)) {
        return (
          <p key={key} className="text-sm py-1" dangerouslySetInnerHTML={{ __html: processedLine }} />
        );
      }

      // Empty lines
      if (!line.trim()) return <br key={key} />;

      // Regular paragraph
      return <p key={key} className="text-sm" dangerouslySetInnerHTML={{ __html: processedLine }} />;
    };

    const renderTable = (rows: string[], key: number): JSX.Element => {
      const headerRow = rows[0];
      const dataRows = rows.slice(2); // Skip separator row

      const headers = headerRow.split('|').filter(h => h.trim()).map(h => h.trim());
      const data = dataRows.map(row => 
        row.split('|').filter(c => c.trim()).map(c => c.trim())
      );

      return (
        <div key={key} className="overflow-x-auto my-2">
          <table className="min-w-full text-xs border border-border rounded">
            <thead className="bg-muted/50">
              <tr>
                {headers.map((h, i) => (
                  <th key={i} className="px-2 py-1 text-left font-medium border-b border-border">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {data.map((row, i) => (
                <tr key={i} className="border-b border-border last:border-0">
                  {row.map((cell, j) => (
                    <td key={j} className="px-2 py-1">{cell}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      );
    };

    lines.forEach((line, i) => {
      const element = processLine(line, i);
      if (element) elements.push(element);
    });

    // Handle remaining table
    if (inTable && tableRows.length > 0) {
      elements.push(renderTable(tableRows, lines.length));
    }

    return elements;
  };

  const hasError = messages.length > 0 && messages[messages.length - 1]?.error;

  return (
    <Card className={cn("flex flex-col h-[600px]", className)}>
      <CardHeader className="pb-3 flex-shrink-0 border-b">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-primary" />
            Consultor de Estoque IA
            <Badge variant="secondary" className="text-xs font-normal">
              Gemini
            </Badge>
          </CardTitle>
          <div className="flex items-center gap-1">
            {messages.length > 0 && (
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={clearMessages}
                title="Limpar conversa"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            )}
          </div>
        </div>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col overflow-hidden p-0">
        <ScrollArea className="flex-1 px-4" ref={scrollRef}>
          {messages.length === 0 ? (
            <div className="space-y-4 py-4">
              <div className="text-center text-muted-foreground">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                  <Bot className="w-8 h-8 text-primary" />
                </div>
                <p className="font-medium text-foreground">Olá! Sou seu consultor de estoque.</p>
                <p className="text-sm mt-1">
                  Posso ajudar com análises, explicar termos técnicos, <br />
                  e sugerir ações para otimizar seu estoque.
                </p>
              </div>
              
              {showQuickQuestions && (
                <div className="space-y-3">
                  <div className="flex items-center gap-2 justify-center text-xs text-muted-foreground">
                    <Lightbulb className="w-3 h-3" />
                    <span>Perguntas sugeridas:</span>
                  </div>
                  <div className="flex flex-wrap gap-2 justify-center">
                    {quickQuestions.slice(0, 6).map((q, i) => (
                      <Button
                        key={i}
                        variant="outline"
                        size="sm"
                        className="text-xs h-auto py-1.5 px-3 whitespace-normal text-left max-w-[200px]"
                        onClick={() => handleQuickQuestion(q)}
                        disabled={isLoading}
                      >
                        {q}
                      </Button>
                    ))}
                  </div>
                </div>
              )}

              {context?.summary && (
                <div className="mt-4 p-3 bg-muted/50 rounded-lg space-y-3">
                  <p className="text-xs text-muted-foreground flex items-center gap-1">
                    <Zap className="w-3 h-3 text-primary" />
                    Dados carregados para análise:
                  </p>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="p-2 bg-background rounded">
                      <span className="text-muted-foreground block">Produtos críticos</span>
                      <span className={cn(
                        "font-bold text-lg",
                        context.summary.criticalProducts > 0 ? "text-destructive" : "text-success"
                      )}>
                        {context.summary.criticalProducts}
                      </span>
                    </div>
                    <div className="p-2 bg-background rounded">
                      <span className="text-muted-foreground block">Cobertura média</span>
                      <span className="font-bold text-lg">
                        {context.summary.averageCoverage?.toFixed(0) || 0}d
                      </span>
                    </div>
                    <div className="p-2 bg-background rounded">
                      <span className="text-muted-foreground block">Valor em estoque</span>
                      <span className="font-bold text-sm">
                        R$ {((context.summary.totalStockValue || 0) / 1000).toFixed(1)}k
                      </span>
                    </div>
                    <div className="p-2 bg-background rounded">
                      <span className="text-muted-foreground block">Rupturas 7d</span>
                      <span className={cn(
                        "font-bold text-lg",
                        context.summary.predictedStockouts7Days > 0 ? "text-warning" : "text-success"
                      )}>
                        {context.summary.predictedStockouts7Days}
                      </span>
                    </div>
                  </div>
                  
                  {context.topCriticalProducts && context.topCriticalProducts.length > 0 && (
                    <div className="pt-2 border-t">
                      <p className="text-xs text-muted-foreground mb-2">Top produtos críticos:</p>
                      <div className="flex flex-wrap gap-1">
                        {context.topCriticalProducts.slice(0, 3).map((p, i) => (
                          <Badge key={i} variant="outline" className="text-xs">
                            {p.name.length > 15 ? p.name.substring(0, 15) + '...' : p.name}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-4 py-4">
              {messages.map((msg, index) => (
                <div
                  key={index}
                  className={cn(
                    "flex gap-3",
                    msg.role === 'user' && "flex-row-reverse"
                  )}
                >
                  <div className={cn(
                    "w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0",
                    msg.role === 'user' 
                      ? "bg-primary" 
                      : msg.error 
                        ? "bg-destructive/10" 
                        : "bg-muted"
                  )}>
                    {msg.role === 'user' ? (
                      <User className="w-4 h-4 text-primary-foreground" />
                    ) : msg.error ? (
                      <AlertCircle className="w-4 h-4 text-destructive" />
                    ) : msg.isStreaming ? (
                      <Loader2 className="w-4 h-4 animate-spin text-primary" />
                    ) : (
                      <Bot className="w-4 h-4 text-muted-foreground" />
                    )}
                  </div>
                  <div className={cn(
                    "max-w-[85%] rounded-lg px-3 py-2",
                    msg.role === 'user' 
                      ? "bg-primary text-primary-foreground" 
                      : msg.error
                        ? "bg-destructive/10 border border-destructive/20"
                        : "bg-muted"
                  )}>
                    {msg.role === 'user' ? (
                      <p className="text-sm">{msg.content}</p>
                    ) : (
                      <div className="prose prose-sm max-w-none dark:prose-invert">
                        {msg.content ? formatMessage(msg.content) : (
                          <span className="text-muted-foreground flex items-center gap-2">
                            Pensando
                            <span className="flex gap-1">
                              <span className="w-1.5 h-1.5 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                              <span className="w-1.5 h-1.5 bg-primary rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                              <span className="w-1.5 h-1.5 bg-primary rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                            </span>
                          </span>
                        )}
                        {msg.isStreaming && msg.content && (
                          <span className="inline-block w-2 h-4 bg-primary/50 animate-pulse ml-0.5" />
                        )}
                      </div>
                    )}
                  </div>
                </div>
              ))}

              {hasError && !isLoading && (
                <div className="flex justify-center">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={handleRetry}
                    className="gap-2"
                  >
                    <RefreshCw className="w-3 h-3" />
                    Tentar novamente
                  </Button>
                </div>
              )}
            </div>
          )}
        </ScrollArea>

        <div className="p-4 border-t flex-shrink-0">
          <form 
            onSubmit={e => { e.preventDefault(); handleSend(); }}
            className="flex gap-2"
          >
            <Input
              ref={inputRef}
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Pergunte sobre estoque, reposição, ABC..."
              disabled={isLoading}
              className="flex-1"
              maxLength={2000}
            />
            {isLoading ? (
              <Button 
                type="button" 
                variant="outline"
                onClick={cancelRequest}
                title="Cancelar"
              >
                <X className="w-4 h-4" />
              </Button>
            ) : (
              <Button 
                type="submit" 
                disabled={!input.trim()}
                title="Enviar"
              >
                <Send className="w-4 h-4" />
              </Button>
            )}
          </form>
          <p className="text-xs text-muted-foreground mt-2 text-center">
            Powered by Google Gemini • Especialista em gestão de estoque
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
