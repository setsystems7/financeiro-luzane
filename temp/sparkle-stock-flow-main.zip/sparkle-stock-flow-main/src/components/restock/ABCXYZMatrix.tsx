import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ABCXYZSummary } from '@/hooks/useABCXYZAnalysis';
import { cn } from '@/lib/utils';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';

interface ABCXYZMatrixProps {
  summary: ABCXYZSummary;
}

const matrixInfo = {
  AX: { 
    label: 'Alta receita, demanda estável', 
    action: 'Manter alto nível de serviço',
    priority: 'critical',
    color: 'bg-success text-success-foreground'
  },
  AY: { 
    label: 'Alta receita, demanda moderada', 
    action: 'Estoque de segurança maior',
    priority: 'high',
    color: 'bg-success/70 text-success-foreground'
  },
  AZ: { 
    label: 'Alta receita, demanda errática', 
    action: 'Análise individual necessária',
    priority: 'high',
    color: 'bg-success/50 text-success-foreground'
  },
  BX: { 
    label: 'Média receita, demanda estável', 
    action: 'Reposição regular',
    priority: 'medium',
    color: 'bg-warning text-warning-foreground'
  },
  BY: { 
    label: 'Média receita, demanda moderada', 
    action: 'Monitorar periodicamente',
    priority: 'medium',
    color: 'bg-warning/70 text-warning-foreground'
  },
  BZ: { 
    label: 'Média receita, demanda errática', 
    action: 'Revisar mix de produtos',
    priority: 'low',
    color: 'bg-warning/50 text-warning-foreground'
  },
  CX: { 
    label: 'Baixa receita, demanda estável', 
    action: 'Automatizar reposição',
    priority: 'low',
    color: 'bg-destructive/70 text-destructive-foreground'
  },
  CY: { 
    label: 'Baixa receita, demanda moderada', 
    action: 'Considerar reduzir variedade',
    priority: 'low',
    color: 'bg-destructive/50 text-destructive-foreground'
  },
  CZ: { 
    label: 'Baixa receita, demanda errática', 
    action: 'Avaliar descontinuação',
    priority: 'low',
    color: 'bg-destructive/30 text-destructive-foreground'
  },
};

export function ABCXYZMatrix({ summary }: ABCXYZMatrixProps) {
  const abcClasses = ['A', 'B', 'C'] as const;
  const xyzClasses = ['X', 'Y', 'Z'] as const;

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base">Matriz ABC × XYZ</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full text-center">
            <thead>
              <tr>
                <th className="p-2 text-xs text-muted-foreground"></th>
                <th className="p-2 text-xs font-medium">X (Estável)</th>
                <th className="p-2 text-xs font-medium">Y (Moderado)</th>
                <th className="p-2 text-xs font-medium">Z (Errático)</th>
              </tr>
            </thead>
            <tbody>
              {abcClasses.map(abc => (
                <tr key={abc}>
                  <td className="p-2 text-xs font-medium">{abc}</td>
                  {xyzClasses.map(xyz => {
                    const key = `${abc}${xyz}` as keyof typeof matrixInfo;
                    const count = summary.matrix[key] || 0;
                    const info = matrixInfo[key];

                    return (
                      <td key={key} className="p-1">
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <div 
                              className={cn(
                                "rounded-lg p-3 cursor-help transition-transform hover:scale-105",
                                info.color
                              )}
                            >
                              <span className="text-lg font-bold">{count}</span>
                            </div>
                          </TooltipTrigger>
                          <TooltipContent side="top" className="max-w-[200px]">
                            <p className="font-semibold">{key}: {info.label}</p>
                            <p className="text-xs mt-1">Ação: {info.action}</p>
                          </TooltipContent>
                        </Tooltip>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-4 space-y-2 text-xs">
          <p className="text-muted-foreground">
            <strong>Eixo ABC:</strong> Contribuição para o faturamento
          </p>
          <p className="text-muted-foreground">
            <strong>Eixo XYZ:</strong> Variabilidade da demanda
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
