import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useRestockAlerts, RestockAlert } from '@/hooks/useRestockAlerts';
import { useRestockCalculations } from '@/hooks/useRestockCalculations';
import { cn } from '@/lib/utils';
import { AlertTriangle, TrendingDown, Package, ArrowRight, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';

export function RestockDashboardWidget() {
  const { data: alerts = [] } = useRestockAlerts();
  const { data: restockData } = useRestockCalculations();

  const criticalAlerts = alerts.filter(a => a.severity === 'critical').slice(0, 3);
  const warningAlerts = alerts.filter(a => a.severity === 'warning').slice(0, 2);
  const displayAlerts = [...criticalAlerts, ...warningAlerts].slice(0, 5);

  const getAlertIcon = (type: RestockAlert['type']) => {
    switch (type) {
      case 'stockout':
        return <Package className="w-4 h-4" />;
      case 'reorder':
        return <TrendingDown className="w-4 h-4" />;
      default:
        return <AlertTriangle className="w-4 h-4" />;
    }
  };

  return (
    <Card className="h-full">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-primary" />
            Inteligência de Reposição
          </CardTitle>
          <Link to="/reposicao">
            <Button variant="ghost" size="sm">
              Ver tudo
              <ArrowRight className="w-4 h-4 ml-1" />
            </Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent>
        {/* Quick Stats */}
        {restockData && (
          <div className="grid grid-cols-3 gap-2 mb-4">
            <div className="text-center p-2 rounded-lg bg-destructive/10">
              <p className="text-xl font-bold text-destructive">
                {restockData.summary.criticalProducts}
              </p>
              <p className="text-xs text-muted-foreground">Críticos</p>
            </div>
            <div className="text-center p-2 rounded-lg bg-warning/10">
              <p className="text-xl font-bold text-warning">
                {restockData.summary.predictedStockouts7Days}
              </p>
              <p className="text-xs text-muted-foreground">Rupturas 7d</p>
            </div>
            <div className="text-center p-2 rounded-lg bg-primary/10">
              <p className="text-xl font-bold text-primary">
                {Math.round(restockData.summary.averageCoverage)}d
              </p>
              <p className="text-xs text-muted-foreground">Cobertura</p>
            </div>
          </div>
        )}

        {/* Alerts List */}
        <div className="space-y-2">
          {displayAlerts.length > 0 ? (
            displayAlerts.map(alert => (
              <div
                key={alert.id}
                className={cn(
                  "flex items-center gap-3 p-2 rounded-lg text-sm",
                  alert.severity === 'critical' && "bg-destructive/10",
                  alert.severity === 'warning' && "bg-warning/10"
                )}
              >
                <div className={cn(
                  "p-1.5 rounded-full",
                  alert.severity === 'critical' && "bg-destructive/20 text-destructive",
                  alert.severity === 'warning' && "bg-warning/20 text-warning"
                )}>
                  {getAlertIcon(alert.type)}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium truncate">{alert.productName}</p>
                  <p className="text-xs text-muted-foreground truncate">{alert.message}</p>
                </div>
                <Badge 
                  variant="outline"
                  className={cn(
                    "shrink-0",
                    alert.severity === 'critical' && "border-destructive text-destructive",
                    alert.severity === 'warning' && "border-warning text-warning"
                  )}
                >
                  {alert.severity === 'critical' ? 'Crítico' : 'Atenção'}
                </Badge>
              </div>
            ))
          ) : (
            <div className="text-center py-4 text-muted-foreground">
              <Package className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">Nenhum alerta de estoque</p>
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="flex gap-2 mt-4">
          <Link to="/reposicao" className="flex-1">
            <Button variant="outline" size="sm" className="w-full">
              Lista de Compras
            </Button>
          </Link>
          <Link to="/reposicao?tab=ai" className="flex-1">
            <Button size="sm" className="w-full">
              <Sparkles className="w-3 h-3 mr-1" />
              Pergunte à IA
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}
