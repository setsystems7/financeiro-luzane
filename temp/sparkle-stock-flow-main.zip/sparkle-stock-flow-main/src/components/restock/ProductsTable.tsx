import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { RestockProduct } from '@/hooks/useRestockCalculations';
import { cn } from '@/lib/utils';
import { Search, ArrowUpDown, Package, AlertTriangle } from 'lucide-react';

interface ProductsTableProps {
  products: RestockProduct[];
}

export function ProductsTable({ products }: ProductsTableProps) {
  const [search, setSearch] = useState('');
  const [abcFilter, setAbcFilter] = useState<string>('all');
  const [urgencyFilter, setUrgencyFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'stock' | 'value' | 'name'>('value');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  const filteredProducts = products
    .filter(p => {
      const matchesSearch = p.productName.toLowerCase().includes(search.toLowerCase()) ||
        p.supplierName?.toLowerCase().includes(search.toLowerCase()) ||
        p.categoryName?.toLowerCase().includes(search.toLowerCase());
      const matchesAbc = abcFilter === 'all' || p.abcClass === abcFilter;
      const matchesUrgency = urgencyFilter === 'all' || p.urgency === urgencyFilter;
      return matchesSearch && matchesAbc && matchesUrgency;
    })
    .sort((a, b) => {
      let comparison = 0;
      if (sortBy === 'stock') {
        comparison = a.currentStock - b.currentStock;
      } else if (sortBy === 'value') {
        comparison = a.stockValue - b.stockValue;
      } else {
        comparison = a.productName.localeCompare(b.productName);
      }
      return sortOrder === 'asc' ? comparison : -comparison;
    });

  const toggleSort = (column: typeof sortBy) => {
    if (sortBy === column) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(column);
      setSortOrder('desc');
    }
  };

  const urgencyConfig = {
    critical: { label: 'Crítico', class: 'bg-destructive text-destructive-foreground' },
    high: { label: 'Alto', class: 'bg-warning text-warning-foreground' },
    medium: { label: 'Médio', class: 'bg-primary/80 text-primary-foreground' },
    low: { label: 'OK', class: 'bg-success/80 text-success-foreground' },
  };

  const abcConfig = {
    A: { class: 'bg-success/20 text-success border-success/30' },
    B: { class: 'bg-warning/20 text-warning border-warning/30' },
    C: { class: 'bg-muted text-muted-foreground' },
  };

  // Calculate max stock value for progress bar
  const maxStockValue = Math.max(...products.map(p => p.stockValue), 1);

  // Summary stats
  const totalValue = filteredProducts.reduce((sum, p) => sum + p.stockValue, 0);
  const totalUnits = filteredProducts.reduce((sum, p) => sum + p.currentStock, 0);
  const zeroStock = filteredProducts.filter(p => p.currentStock === 0).length;

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex flex-col gap-4">
          <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <Package className="w-4 h-4 text-primary" />
                Análise de Produtos
              </CardTitle>
              <p className="text-xs text-muted-foreground mt-1">
                {filteredProducts.length} produtos • {totalUnits} unidades • 
                R$ {totalValue.toLocaleString('pt-BR', { minimumFractionDigits: 0 })}
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar..."
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  className="pl-8 w-[180px] h-9"
                />
              </div>
              <Select value={abcFilter} onValueChange={setAbcFilter}>
                <SelectTrigger className="w-[100px] h-9">
                  <SelectValue placeholder="ABC" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas</SelectItem>
                  <SelectItem value="A">Classe A</SelectItem>
                  <SelectItem value="B">Classe B</SelectItem>
                  <SelectItem value="C">Classe C</SelectItem>
                </SelectContent>
              </Select>
              <Select value={urgencyFilter} onValueChange={setUrgencyFilter}>
                <SelectTrigger className="w-[110px] h-9">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  <SelectItem value="critical">Crítico</SelectItem>
                  <SelectItem value="high">Alto</SelectItem>
                  <SelectItem value="medium">Médio</SelectItem>
                  <SelectItem value="low">OK</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Quick stats */}
          {zeroStock > 0 && (
            <div className="flex items-center gap-2 text-sm text-destructive">
              <AlertTriangle className="w-4 h-4" />
              <span>{zeroStock} produtos sem estoque</span>
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead className="w-[250px]">
                  <button 
                    onClick={() => toggleSort('name')}
                    className="flex items-center gap-1 hover:text-foreground"
                  >
                    Produto
                    <ArrowUpDown className="w-3 h-3" />
                  </button>
                </TableHead>
                <TableHead className="text-center w-[80px]">Classe</TableHead>
                <TableHead className="text-center w-[100px]">
                  <button 
                    onClick={() => toggleSort('stock')}
                    className="flex items-center gap-1 justify-center hover:text-foreground"
                  >
                    Estoque
                    <ArrowUpDown className="w-3 h-3" />
                  </button>
                </TableHead>
                <TableHead className="w-[200px]">
                  <button 
                    onClick={() => toggleSort('value')}
                    className="flex items-center gap-1 hover:text-foreground"
                  >
                    Valor em Estoque
                    <ArrowUpDown className="w-3 h-3" />
                  </button>
                </TableHead>
                <TableHead className="text-center w-[80px]">Margem</TableHead>
                <TableHead className="text-center w-[90px]">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredProducts.slice(0, 50).map(product => {
                const margin = product.costPrice > 0 
                  ? ((product.salePrice - product.costPrice) / product.costPrice) * 100 
                  : 0;
                const stockPercent = (product.stockValue / maxStockValue) * 100;

                return (
                  <TableRow key={product.productId}>
                    <TableCell>
                      <div>
                        <p className="font-medium text-sm truncate max-w-[230px]" title={product.productName}>
                          {product.productName}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {product.categoryName || product.supplierName || 'Sem categoria'}
                        </p>
                      </div>
                    </TableCell>
                    <TableCell className="text-center">
                      <div className="flex items-center justify-center gap-1">
                        <Badge variant="outline" className={cn("text-xs", abcConfig[product.abcClass].class)}>
                          {product.abcClass}
                        </Badge>
                        <span className="text-xs text-muted-foreground">{product.xyzClass}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-center">
                      <span className={cn(
                        "font-semibold",
                        product.currentStock === 0 && "text-destructive"
                      )}>
                        {product.currentStock}
                      </span>
                      <span className="text-xs text-muted-foreground"> un</span>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="flex justify-between text-xs">
                          <span className="font-medium">
                            R$ {product.stockValue.toLocaleString('pt-BR', { minimumFractionDigits: 0 })}
                          </span>
                        </div>
                        <Progress 
                          value={stockPercent} 
                          className="h-1.5"
                        />
                      </div>
                    </TableCell>
                    <TableCell className="text-center">
                      <span className={cn(
                        "text-sm font-medium",
                        margin >= 50 && "text-success",
                        margin >= 30 && margin < 50 && "text-primary",
                        margin < 30 && "text-warning"
                      )}>
                        {margin.toFixed(0)}%
                      </span>
                    </TableCell>
                    <TableCell className="text-center">
                      <Badge className={cn("text-xs", urgencyConfig[product.urgency].class)}>
                        {urgencyConfig[product.urgency].label}
                      </Badge>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
        
        {filteredProducts.length > 50 && (
          <p className="text-xs text-muted-foreground mt-3 text-center">
            Mostrando 50 de {filteredProducts.length} produtos
          </p>
        )}
      </CardContent>
    </Card>
  );
}
