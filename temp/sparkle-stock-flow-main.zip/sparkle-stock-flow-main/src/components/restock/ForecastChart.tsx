import * as React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { DemandForecast } from '@/hooks/useDemandForecast';
import { TrendingUp, TrendingDown, Minus, BarChart3 } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ForecastChartProps {
  forecasts: DemandForecast[];
}

export function ForecastChart({ forecasts }: ForecastChartProps) {
  if (!forecasts || forecasts.length === 0) return null;

  // Prepare data for comparison chart
  const comparisonData = forecasts.map(f => ({
    name: f.productName.length > 15 ? f.productName.substring(0, 15) + '...' : f.productName,
    fullName: f.productName,
    atual: f.currentStock,
    demanda30: Math.round(f.forecastedDemand30Days),
    diasRuptura: f.daysUntilStockout,
    trend: f.trendDirection,
    trendPercent: f.trendPercentage,
  }));

  const CustomTooltip = React.forwardRef<HTMLDivElement, any>(({ active, payload }, ref) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div ref={ref} className="bg-popover border border-border rounded-lg p-3 shadow-lg text-sm">
          <p className="font-semibold mb-2">{data.fullName}</p>
          <div className="space-y-1">
            <div className="flex justify-between gap-4">
              <span className="text-muted-foreground">Estoque Atual:</span>
              <span className="font-medium">{data.atual} un</span>
            </div>
            <div className="flex justify-between gap-4">
              <span className="text-muted-foreground">Demanda 30d:</span>
              <span className="font-medium">{data.demanda30} un</span>
            </div>
            <div className="flex justify-between gap-4">
              <span className="text-muted-foreground">Dias p/ Ruptura:</span>
              <span className={cn(
                "font-medium",
                data.diasRuptura !== null && data.diasRuptura <= 7 && "text-destructive"
              )}>
                {data.diasRuptura !== null ? `${data.diasRuptura} dias` : 'Sem demanda'}
              </span>
            </div>
          </div>
        </div>
      );
    }
    return null;
  });

  const getBarColor = (entry: any) => {
    if (entry.diasRuptura !== null && entry.diasRuptura <= 7) return 'hsl(var(--destructive))';
    if (entry.diasRuptura !== null && entry.diasRuptura <= 14) return 'hsl(var(--warning))';
    return 'hsl(var(--primary))';
  };

  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-primary" />
            Previsão de Demanda - Top Produtos
          </CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-[280px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={comparisonData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} className="stroke-muted" />
              <XAxis type="number" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
              <YAxis 
                dataKey="name" 
                type="category" 
                tick={{ fontSize: 11 }} 
                tickLine={false} 
                axisLine={false}
                width={100}
              />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="atual" name="Estoque Atual" stackId="a" radius={[0, 0, 0, 0]}>
                {comparisonData.map((entry, index) => (
                  <Cell key={`cell-atual-${index}`} fill="hsl(var(--muted-foreground))" fillOpacity={0.3} />
                ))}
              </Bar>
              <Bar dataKey="demanda30" name="Demanda 30d" stackId="b" radius={[0, 4, 4, 0]}>
                {comparisonData.map((entry, index) => (
                  <Cell key={`cell-demanda-${index}`} fill={getBarColor(entry)} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Legend and Summary */}
        <div className="flex flex-wrap items-center justify-center gap-4 mt-4 text-xs">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded bg-muted-foreground/30" />
            <span className="text-muted-foreground">Estoque Atual</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded bg-primary" />
            <span className="text-muted-foreground">Demanda 30 dias</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded bg-warning" />
            <span className="text-muted-foreground">Atenção (≤14d)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded bg-destructive" />
            <span className="text-muted-foreground">Crítico (≤7d)</span>
          </div>
        </div>

        {/* Trend indicators */}
        <div className="grid grid-cols-5 gap-2 mt-4">
          {forecasts.slice(0, 5).map((f, i) => (
            <div key={i} className="text-center p-2 rounded-lg bg-muted/50">
              <div className={cn(
                "flex items-center justify-center gap-1 text-xs",
                f.trendDirection === 'up' && "text-success",
                f.trendDirection === 'down' && "text-destructive",
                f.trendDirection === 'stable' && "text-muted-foreground",
              )}>
                {f.trendDirection === 'up' && <TrendingUp className="w-3 h-3" />}
                {f.trendDirection === 'down' && <TrendingDown className="w-3 h-3" />}
                {f.trendDirection === 'stable' && <Minus className="w-3 h-3" />}
                <span>{f.trendPercentage > 0 ? '+' : ''}{f.trendPercentage.toFixed(0)}%</span>
              </div>
              <p className="text-xs text-muted-foreground mt-1 truncate" title={f.productName}>
                {f.productName.length > 10 ? f.productName.substring(0, 10) + '...' : f.productName}
              </p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
