import { Card, CardContent } from '@/components/ui/card';
import { RestockSummary } from '@/hooks/useRestockCalculations';
import { AlertTriangle, Package, Calendar, DollarSign, TrendingDown, Boxes } from 'lucide-react';
import { cn } from '@/lib/utils';

interface RestockKPIsProps {
  summary: RestockSummary;
}

export function RestockKPIs({ summary }: RestockKPIsProps) {
  const kpis = [
    {
      title: 'Produtos Críticos',
      value: summary.criticalProducts,
      subtitle: 'ruptura iminente',
      icon: AlertTriangle,
      color: summary.criticalProducts > 0 ? 'text-destructive' : 'text-success',
      bgColor: summary.criticalProducts > 0 ? 'bg-destructive/10' : 'bg-success/10',
    },
    {
      title: 'Rupturas em 7 dias',
      value: summary.predictedStockouts7Days,
      subtitle: 'produtos previstos',
      icon: TrendingDown,
      color: summary.predictedStockouts7Days > 0 ? 'text-warning' : 'text-success',
      bgColor: summary.predictedStockouts7Days > 0 ? 'bg-warning/10' : 'bg-success/10',
    },
    {
      title: 'Cobertura Média',
      value: `${Math.round(summary.averageCoverage)} dias`,
      subtitle: 'de estoque',
      icon: Calendar,
      color: summary.averageCoverage < 14 ? 'text-warning' : 'text-primary',
      bgColor: summary.averageCoverage < 14 ? 'bg-warning/10' : 'bg-primary/10',
    },
    {
      title: 'Valor Total Estoque',
      value: `R$ ${(summary.totalStockValue / 1000).toFixed(1)}k`,
      subtitle: 'em produtos',
      icon: Boxes,
      color: 'text-primary',
      bgColor: 'bg-primary/10',
    },
    {
      title: 'Capital Parado',
      value: `R$ ${(summary.excessStockValue / 1000).toFixed(1)}k`,
      subtitle: '>90 dias cobertura',
      icon: DollarSign,
      color: summary.excessStockValue > 0 ? 'text-warning' : 'text-success',
      bgColor: summary.excessStockValue > 0 ? 'bg-warning/10' : 'bg-success/10',
    },
    {
      title: 'Custo de Reposição',
      value: `R$ ${(summary.totalSuggestedCost / 1000).toFixed(1)}k`,
      subtitle: 'sugerido para compras',
      icon: Package,
      color: 'text-primary',
      bgColor: 'bg-primary/10',
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
      {kpis.map((kpi, index) => (
        <Card key={index} className="hover:shadow-md transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-start justify-between">
              <div className={cn("p-2 rounded-lg", kpi.bgColor)}>
                <kpi.icon className={cn("w-4 h-4", kpi.color)} />
              </div>
            </div>
            <div className="mt-3">
              <p className={cn("text-xl font-bold", kpi.color)}>{kpi.value}</p>
              <p className="text-xs text-muted-foreground mt-1">{kpi.title}</p>
              <p className="text-xs text-muted-foreground">{kpi.subtitle}</p>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
