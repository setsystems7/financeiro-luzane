import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Loader2 } from 'lucide-react';
import { format, subDays, startOfDay } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export function SalesChart() {
  const { data: chartData = [], isLoading } = useQuery({
    queryKey: ['sales-chart'],
    queryFn: async () => {
      const days = 7;
      const result = [];
      
      for (let i = days - 1; i >= 0; i--) {
        const date = subDays(new Date(), i);
        const startOfDayDate = startOfDay(date);
        const endOfDayDate = new Date(startOfDayDate);
        endOfDayDate.setHours(23, 59, 59, 999);

        const { data, error } = await supabase
          .from('sales')
          .select('final_total')
          .gte('created_at', startOfDayDate.toISOString())
          .lte('created_at', endOfDayDate.toISOString())
          .eq('status', 'concluida');

        if (error) throw error;

        const total = data.reduce((acc, sale) => acc + Number(sale.final_total), 0);
        
        result.push({
          name: format(date, 'EEE', { locale: ptBR }),
          vendas: total,
        });
      }
      
      return result;
    },
  });

  return (
    <Card variant="elevated" className="col-span-2">
      <CardHeader>
        <CardTitle className="text-lg font-semibold">Vendas - Últimos 7 dias</CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="h-[300px] flex items-center justify-center">
            <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorVendas" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(340, 82%, 86%)" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="hsl(340, 82%, 86%)" stopOpacity={0.1}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(340, 20%, 90%)" />
                <XAxis 
                  dataKey="name" 
                  stroke="hsl(340, 10%, 45%)" 
                  fontSize={12}
                  tickLine={false}
                />
                <YAxis 
                  stroke="hsl(340, 10%, 45%)" 
                  fontSize={12}
                  tickLine={false}
                  tickFormatter={(value) => value >= 1000 ? `R$${(value / 1000).toFixed(1)}k` : `R$${value}`}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(0, 0%, 100%)', 
                    border: '1px solid hsl(340, 20%, 90%)',
                    borderRadius: '8px',
                    boxShadow: '0 4px 6px -1px hsl(340, 20%, 50%, 0.1)'
                  }}
                  formatter={(value: number) => [`R$ ${value.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, 'Vendas']}
                />
                <Area 
                  type="monotone" 
                  dataKey="vendas" 
                  stroke="hsl(340, 82%, 76%)" 
                  fillOpacity={1} 
                  fill="url(#colorVendas)"
                  strokeWidth={2}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
