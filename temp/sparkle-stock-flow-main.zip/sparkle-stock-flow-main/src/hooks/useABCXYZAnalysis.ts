import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface ProductABCXYZ {
  productId: string;
  productName: string;
  categoryName: string | null;
  supplierName: string | null;
  supplierId: string | null;
  totalRevenue: number;
  totalQuantitySold: number;
  revenuePercentage: number;
  cumulativePercentage: number;
  abcClass: 'A' | 'B' | 'C';
  demandVariability: number;
  xyzClass: 'X' | 'Y' | 'Z';
  currentStock: number;
  costPrice: number;
  salePrice: number;
  margin: number;
  marginPercentage: number;
}

export interface ABCXYZSummary {
  totalProducts: number;
  totalRevenue: number;
  classA: { count: number; revenue: number; percentage: number };
  classB: { count: number; revenue: number; percentage: number };
  classC: { count: number; revenue: number; percentage: number };
  classX: { count: number };
  classY: { count: number };
  classZ: { count: number };
  matrix: Record<string, number>;
}

export function useABCXYZAnalysis(days: number = 90) {
  return useQuery({
    queryKey: ['abc-xyz-analysis', days],
    queryFn: async () => {
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - days);

      // Get all products with their info
      const { data: products, error: productsError } = await supabase
        .from('products')
        .select(`
          id,
          name,
          cost_price,
          sale_price,
          supplier_id,
          suppliers (name),
          category_id,
          categories (name),
          product_sizes (quantity)
        `)
        .eq('is_active', true);

      if (productsError) throw productsError;

      // Get sales data for the period
      const { data: saleItems, error: salesError } = await supabase
        .from('sale_items')
        .select(`
          product_id,
          quantity,
          unit_price,
          total,
          created_at
        `)
        .gte('created_at', startDate.toISOString());

      if (salesError) throw salesError;

      // Calculate revenue and quantities per product
      const productStats = new Map<string, {
        revenue: number;
        quantitySold: number;
        salesByWeek: number[];
      }>();

      // Initialize all products
      products?.forEach(p => {
        productStats.set(p.id, { revenue: 0, quantitySold: 0, salesByWeek: [] });
      });

      // Group sales by week for variability calculation
      const weeksInPeriod = Math.ceil(days / 7);
      
      saleItems?.forEach(item => {
        if (!item.product_id) return;
        
        const stats = productStats.get(item.product_id);
        if (stats) {
          stats.revenue += Number(item.total) || 0;
          stats.quantitySold += item.quantity || 0;
          
          // Calculate which week this sale belongs to
          const saleDate = new Date(item.created_at);
          const weekIndex = Math.floor((new Date().getTime() - saleDate.getTime()) / (7 * 24 * 60 * 60 * 1000));
          if (!stats.salesByWeek[weekIndex]) stats.salesByWeek[weekIndex] = 0;
          stats.salesByWeek[weekIndex] += item.quantity || 0;
        }
      });

      // Calculate total revenue
      let totalRevenue = 0;
      productStats.forEach(stats => {
        totalRevenue += stats.revenue;
      });

      // Build analysis array
      const analysisData: ProductABCXYZ[] = [];
      
      products?.forEach(product => {
        const stats = productStats.get(product.id) || { revenue: 0, quantitySold: 0, salesByWeek: [] };
        const currentStock = product.product_sizes?.reduce((sum, ps) => sum + (ps.quantity || 0), 0) || 0;
        
        // Calculate demand variability (Coefficient of Variation)
        const weeklyValues = Array(weeksInPeriod).fill(0);
        stats.salesByWeek.forEach((val, idx) => {
          if (idx < weeksInPeriod) weeklyValues[idx] = val;
        });
        
        const mean = weeklyValues.reduce((a, b) => a + b, 0) / weeksInPeriod;
        const variance = weeklyValues.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / weeksInPeriod;
        const stdDev = Math.sqrt(variance);
        const cv = mean > 0 ? (stdDev / mean) * 100 : 100;

        // Determine XYZ class based on CV
        let xyzClass: 'X' | 'Y' | 'Z' = 'Z';
        if (cv <= 20) xyzClass = 'X';
        else if (cv <= 50) xyzClass = 'Y';

        const margin = Number(product.sale_price) - Number(product.cost_price);
        const marginPercentage = Number(product.cost_price) > 0 
          ? (margin / Number(product.cost_price)) * 100 
          : 0;

        analysisData.push({
          productId: product.id,
          productName: product.name,
          categoryName: (product.categories as any)?.name || null,
          supplierName: (product.suppliers as any)?.name || null,
          supplierId: product.supplier_id,
          totalRevenue: stats.revenue,
          totalQuantitySold: stats.quantitySold,
          revenuePercentage: totalRevenue > 0 ? (stats.revenue / totalRevenue) * 100 : 0,
          cumulativePercentage: 0,
          abcClass: 'C',
          demandVariability: cv,
          xyzClass,
          currentStock,
          costPrice: Number(product.cost_price),
          salePrice: Number(product.sale_price),
          margin,
          marginPercentage,
        });
      });

      // Sort by revenue descending
      analysisData.sort((a, b) => b.totalRevenue - a.totalRevenue);

      // Calculate cumulative percentages and ABC classification
      let cumulative = 0;
      analysisData.forEach(item => {
        cumulative += item.revenuePercentage;
        item.cumulativePercentage = cumulative;
        
        if (cumulative <= 80) item.abcClass = 'A';
        else if (cumulative <= 95) item.abcClass = 'B';
        else item.abcClass = 'C';
      });

      // Calculate summary
      const summary: ABCXYZSummary = {
        totalProducts: analysisData.length,
        totalRevenue,
        classA: { count: 0, revenue: 0, percentage: 0 },
        classB: { count: 0, revenue: 0, percentage: 0 },
        classC: { count: 0, revenue: 0, percentage: 0 },
        classX: { count: 0 },
        classY: { count: 0 },
        classZ: { count: 0 },
        matrix: {},
      };

      analysisData.forEach(item => {
        // ABC counts
        if (item.abcClass === 'A') {
          summary.classA.count++;
          summary.classA.revenue += item.totalRevenue;
        } else if (item.abcClass === 'B') {
          summary.classB.count++;
          summary.classB.revenue += item.totalRevenue;
        } else {
          summary.classC.count++;
          summary.classC.revenue += item.totalRevenue;
        }

        // XYZ counts
        if (item.xyzClass === 'X') summary.classX.count++;
        else if (item.xyzClass === 'Y') summary.classY.count++;
        else summary.classZ.count++;

        // Matrix counts
        const matrixKey = `${item.abcClass}${item.xyzClass}`;
        summary.matrix[matrixKey] = (summary.matrix[matrixKey] || 0) + 1;
      });

      summary.classA.percentage = totalRevenue > 0 ? (summary.classA.revenue / totalRevenue) * 100 : 0;
      summary.classB.percentage = totalRevenue > 0 ? (summary.classB.revenue / totalRevenue) * 100 : 0;
      summary.classC.percentage = totalRevenue > 0 ? (summary.classC.revenue / totalRevenue) * 100 : 0;

      return { products: analysisData, summary };
    },
    staleTime: 5 * 60 * 1000, // 5 minutes
  });
}
