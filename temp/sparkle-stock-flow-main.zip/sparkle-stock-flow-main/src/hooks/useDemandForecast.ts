import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface DemandForecast {
  productId: string;
  productName: string;
  currentStock: number;
  dailyDemand: number;
  weeklyDemand: number;
  monthlyDemand: number;
  trendDirection: 'up' | 'down' | 'stable';
  trendPercentage: number;
  seasonalityIndex: number;
  confidenceLevel: number;
  daysUntilStockout: number | null;
  forecastedDemand30Days: number;
  forecastedDemand60Days: number;
  forecastedDemand90Days: number;
  historicalData: { date: string; quantity: number }[];
}

export function useDemandForecast(productId?: string) {
  return useQuery({
    queryKey: ['demand-forecast', productId],
    queryFn: async () => {
      // Get sales data for the last 90 days
      const endDate = new Date();
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - 90);

      // Get products
      const productsQuery = supabase
        .from('products')
        .select(`
          id,
          name,
          product_sizes (quantity)
        `)
        .eq('is_active', true);

      if (productId) {
        productsQuery.eq('id', productId);
      }

      const { data: products, error: productsError } = await productsQuery;
      if (productsError) throw productsError;

      // Get sales data
      const { data: saleItems, error: salesError } = await supabase
        .from('sale_items')
        .select(`
          product_id,
          quantity,
          created_at
        `)
        .gte('created_at', startDate.toISOString())
        .order('created_at', { ascending: true });

      if (salesError) throw salesError;

      // Group sales by product and date
      const productSales = new Map<string, Map<string, number>>();
      
      saleItems?.forEach(item => {
        if (!item.product_id) return;
        
        if (!productSales.has(item.product_id)) {
          productSales.set(item.product_id, new Map());
        }
        
        const dateKey = new Date(item.created_at).toISOString().split('T')[0];
        const dateSales = productSales.get(item.product_id)!;
        dateSales.set(dateKey, (dateSales.get(dateKey) || 0) + item.quantity);
      });

      const forecasts: DemandForecast[] = [];

      products?.forEach(product => {
        const salesData = productSales.get(product.id) || new Map();
        const currentStock = product.product_sizes?.reduce((sum, ps) => sum + (ps.quantity || 0), 0) || 0;

        // Create historical data array
        const historicalData: { date: string; quantity: number }[] = [];
        const dailySales: number[] = [];
        
        // Fill in all days in the period
        for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
          const dateKey = d.toISOString().split('T')[0];
          const qty = salesData.get(dateKey) || 0;
          historicalData.push({ date: dateKey, quantity: qty });
          dailySales.push(qty);
        }

        // Calculate weighted moving average (more recent = more weight)
        const month1 = dailySales.slice(-30);
        const month2 = dailySales.slice(-60, -30);
        const month3 = dailySales.slice(-90, -60);

        const avg1 = month1.length > 0 ? month1.reduce((a, b) => a + b, 0) / month1.length : 0;
        const avg2 = month2.length > 0 ? month2.reduce((a, b) => a + b, 0) / month2.length : 0;
        const avg3 = month3.length > 0 ? month3.reduce((a, b) => a + b, 0) / month3.length : 0;

        // Weighted average: 50% last month, 30% previous, 20% before that
        const weightedDailyDemand = (avg1 * 0.5) + (avg2 * 0.3) + (avg3 * 0.2);

        // Calculate trend using linear regression on weekly data
        const weeklyData: number[] = [];
        for (let i = 0; i < dailySales.length; i += 7) {
          const weekSlice = dailySales.slice(i, i + 7);
          weeklyData.push(weekSlice.reduce((a, b) => a + b, 0));
        }

        let trendDirection: 'up' | 'down' | 'stable' = 'stable';
        let trendPercentage = 0;

        if (weeklyData.length >= 2) {
          const n = weeklyData.length;
          const sumX = (n * (n - 1)) / 2;
          const sumY = weeklyData.reduce((a, b) => a + b, 0);
          const sumXY = weeklyData.reduce((sum, y, x) => sum + x * y, 0);
          const sumX2 = (n * (n - 1) * (2 * n - 1)) / 6;

          const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
          const avgWeekly = sumY / n;
          
          if (avgWeekly > 0) {
            trendPercentage = (slope / avgWeekly) * 100;
            if (trendPercentage > 5) trendDirection = 'up';
            else if (trendPercentage < -5) trendDirection = 'down';
          }
        }

        // Calculate seasonality index (simplified - compare to average)
        const totalSales = dailySales.reduce((a, b) => a + b, 0);
        const avgDaily = totalSales / dailySales.length;
        const recentAvg = month1.length > 0 ? month1.reduce((a, b) => a + b, 0) / month1.length : 0;
        const seasonalityIndex = avgDaily > 0 ? recentAvg / avgDaily : 1;

        // Calculate confidence level based on data consistency
        const variance = dailySales.reduce((sum, val) => sum + Math.pow(val - avgDaily, 2), 0) / dailySales.length;
        const stdDev = Math.sqrt(variance);
        const cv = avgDaily > 0 ? stdDev / avgDaily : 1;
        const confidenceLevel = Math.max(0.5, Math.min(0.95, 1 - (cv / 2)));

        // Days until stockout
        const daysUntilStockout = weightedDailyDemand > 0 
          ? Math.round(currentStock / weightedDailyDemand) 
          : null;

        // Apply trend to forecasts
        const trendMultiplier = 1 + (trendPercentage / 100);
        
        forecasts.push({
          productId: product.id,
          productName: product.name,
          currentStock,
          dailyDemand: weightedDailyDemand,
          weeklyDemand: weightedDailyDemand * 7,
          monthlyDemand: weightedDailyDemand * 30,
          trendDirection,
          trendPercentage,
          seasonalityIndex,
          confidenceLevel,
          daysUntilStockout,
          forecastedDemand30Days: weightedDailyDemand * 30 * trendMultiplier * seasonalityIndex,
          forecastedDemand60Days: weightedDailyDemand * 60 * Math.pow(trendMultiplier, 2) * seasonalityIndex,
          forecastedDemand90Days: weightedDailyDemand * 90 * Math.pow(trendMultiplier, 3) * seasonalityIndex,
          historicalData: historicalData.slice(-30), // Last 30 days for chart
        });
      });

      // Sort by daily demand descending
      forecasts.sort((a, b) => b.dailyDemand - a.dailyDemand);

      return forecasts;
    },
    staleTime: 10 * 60 * 1000, // 10 minutes
  });
}
