import { useState, useCallback, useRef } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface AIMessage {
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  error?: boolean;
  isStreaming?: boolean;
}

export interface RestockContext {
  summary?: {
    criticalProducts: number;
    totalStockValue: number;
    averageCoverage: number;
    predictedStockouts7Days: number;
  };
  topCriticalProducts?: Array<{
    name: string;
    currentStock: number;
    daysUntilStockout: number | null;
    dailyDemand: number;
  }>;
  abcSummary?: {
    classA: { count: number; percentage: number };
    classB: { count: number; percentage: number };
    classC: { count: number; percentage: number };
  };
  excessStock?: {
    count: number;
    value: number;
  };
  lowMarginProducts?: Array<{
    name: string;
    margin: number;
  }>;
}

const STREAM_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/restock-ai-advisor`;

export function useRestockAI() {
  const [messages, setMessages] = useState<AIMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();
  const abortControllerRef = useRef<AbortController | null>(null);

  const sendMessage = useCallback(async (
    userMessage: string,
    context?: RestockContext
  ): Promise<string | null> => {
    const trimmedMessage = userMessage.trim();
    if (!trimmedMessage) {
      toast.error('Por favor, digite uma mensagem.');
      return null;
    }

    // Create user message
    const userMsg: AIMessage = {
      role: 'user',
      content: trimmedMessage,
      timestamp: new Date(),
    };

    // Create placeholder for assistant message (streaming)
    const assistantPlaceholder: AIMessage = {
      role: 'assistant',
      content: '',
      timestamp: new Date(),
      isStreaming: true,
    };

    setMessages(prev => [...prev, userMsg, assistantPlaceholder]);
    setIsLoading(true);
    setError(null);

    abortControllerRef.current = new AbortController();

    try {
      const response = await fetch(STREAM_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
        },
        body: JSON.stringify({
          message: trimmedMessage,
          context,
          conversationHistory: messages.slice(-10).map(m => ({
            role: m.role,
            content: m.content,
          })),
          stream: true,
        }),
        signal: abortControllerRef.current.signal,
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `Error: ${response.status}`);
      }

      const contentType = response.headers.get('content-type') || '';
      
      if (contentType.includes('text/event-stream')) {
        // Handle SSE streaming
        const reader = response.body?.getReader();
        if (!reader) throw new Error('No reader available');

        const decoder = new TextDecoder();
        let fullContent = '';
        let buffer = '';

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          
          // Process complete SSE events
          const lines = buffer.split('\n');
          buffer = lines.pop() || ''; // Keep incomplete line in buffer

          for (const line of lines) {
            if (line.startsWith('data: ')) {
              const jsonStr = line.slice(6).trim();
              
              if (jsonStr === '[DONE]') continue;
              if (!jsonStr) continue;

              try {
                const data = JSON.parse(jsonStr);
                
                // Handle Gemini direct streaming format
                if (data.candidates?.[0]?.content?.parts?.[0]?.text) {
                  const text = data.candidates[0].content.parts[0].text;
                  fullContent += text;
                  
                  // Update streaming message
                  setMessages(prev => {
                    const newMessages = [...prev];
                    const lastMsg = newMessages[newMessages.length - 1];
                    if (lastMsg?.isStreaming) {
                      lastMsg.content = fullContent;
                    }
                    return newMessages;
                  });
                }
                
                // Handle OpenAI/Lovable AI format
                if (data.choices?.[0]?.delta?.content) {
                  const text = data.choices[0].delta.content;
                  fullContent += text;
                  
                  setMessages(prev => {
                    const newMessages = [...prev];
                    const lastMsg = newMessages[newMessages.length - 1];
                    if (lastMsg?.isStreaming) {
                      lastMsg.content = fullContent;
                    }
                    return newMessages;
                  });
                }
              } catch (e) {
                // Ignore JSON parse errors for incomplete chunks
                console.debug('Stream parse skip:', jsonStr.substring(0, 50));
              }
            }
          }
        }

        // Finalize the message
        setMessages(prev => {
          const newMessages = [...prev];
          const lastMsg = newMessages[newMessages.length - 1];
          if (lastMsg?.isStreaming) {
            lastMsg.isStreaming = false;
            lastMsg.content = fullContent || 'Sem resposta';
          }
          return newMessages;
        });

        // Save conversation
        if (user && fullContent) {
          saveConversation(context, [...messages, userMsg, { ...assistantPlaceholder, content: fullContent, isStreaming: false }]);
        }

        return fullContent;

      } else {
        // Handle non-streaming response
        const data = await response.json();
        const content = data.response || data.error || 'Sem resposta';

        setMessages(prev => {
          const newMessages = [...prev];
          const lastMsg = newMessages[newMessages.length - 1];
          if (lastMsg?.isStreaming) {
            lastMsg.isStreaming = false;
            lastMsg.content = content;
            lastMsg.error = !!data.error;
          }
          return newMessages;
        });

        if (user && !data.error) {
          saveConversation(context, [...messages, userMsg, { ...assistantPlaceholder, content, isStreaming: false }]);
        }

        return content;
      }

    } catch (err) {
      if (err instanceof Error && err.name === 'AbortError') {
        console.log('Request aborted');
        setMessages(prev => prev.slice(0, -1)); // Remove placeholder
        return null;
      }

      console.error('AI Error:', err);
      const errorMessage = err instanceof Error ? err.message : 'Erro desconhecido';
      setError(errorMessage);

      setMessages(prev => {
        const newMessages = [...prev];
        const lastMsg = newMessages[newMessages.length - 1];
        if (lastMsg?.isStreaming) {
          lastMsg.isStreaming = false;
          lastMsg.content = getErrorMessage(errorMessage);
          lastMsg.error = true;
        }
        return newMessages;
      });

      return null;
    } finally {
      setIsLoading(false);
      abortControllerRef.current = null;
    }
  }, [messages, user]);

  const saveConversation = async (context: RestockContext | undefined, allMessages: AIMessage[]) => {
    if (!user) return;
    
    try {
      await supabase.from('ai_conversations').insert([{
        user_id: user.id,
        title: allMessages[0]?.content.slice(0, 50) || 'Conversa',
        context_data: context ? JSON.parse(JSON.stringify(context)) : null,
        messages: JSON.parse(JSON.stringify(allMessages.map(m => ({
          role: m.role,
          content: m.content,
          timestamp: m.timestamp.toISOString(),
        })))),
      }]);
    } catch (err) {
      console.warn('Failed to save conversation:', err);
    }
  };

  const cancelRequest = useCallback(() => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      setIsLoading(false);
      toast.info('Requisição cancelada.');
    }
  }, []);

  const clearMessages = useCallback(() => {
    setMessages([]);
    setError(null);
  }, []);

  const retryLastMessage = useCallback(async (context?: RestockContext) => {
    const userMessages = messages.filter(m => m.role === 'user');
    if (userMessages.length === 0) return null;
    
    const lastUserMsg = userMessages[userMessages.length - 1];
    
    // Remove last messages (user + error)
    setMessages(prev => {
      const lastUserIndex = prev.map(m => m.role).lastIndexOf('user');
      return prev.slice(0, lastUserIndex);
    });
    
    return sendMessage(lastUserMsg.content, context);
  }, [messages, sendMessage]);

  const quickQuestions = [
    'Quais produtos devo priorizar na reposição?',
    'Como calcular o ponto de reposição ideal?',
    'O que significa curva ABC?',
    'Como reduzir o capital parado em estoque?',
    'Qual a diferença entre estoque de segurança e ponto de reposição?',
    'Como melhorar o giro de estoque?',
    'Explique a matriz ABC-XYZ',
    'Como definir o lote econômico de compra (EOQ)?',
    'Quais métricas devo acompanhar no estoque?',
    'Como negociar melhor com fornecedores?',
  ];

  return {
    messages,
    isLoading,
    error,
    sendMessage,
    clearMessages,
    cancelRequest,
    retryLastMessage,
    quickQuestions,
  };
}

function getErrorMessage(error: string): string {
  if (error.includes('network') || error.includes('fetch')) {
    return '⚠️ **Erro de conexão**\n\nNão foi possível conectar ao servidor. Verifique sua internet.';
  }
  if (error.includes('429') || error.includes('rate')) {
    return '⏳ **Limite de requisições**\n\nAguarde alguns segundos antes de continuar.';
  }
  if (error.includes('402')) {
    return '💳 **Créditos esgotados**\n\nAdicione mais créditos para continuar.';
  }
  return `❌ **Erro**\n\n${error}\n\nTente novamente.`;
}
