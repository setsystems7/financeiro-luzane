import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useRestockCalculations } from './useRestockCalculations';

export interface PurchaseItem {
  productId: string;
  productName: string;
  supplierId: string | null;
  supplierName: string | null;
  currentStock: number;
  suggestedQuantity: number;
  adjustedQuantity: number;
  unitCost: number;
  totalCost: number;
  urgency: 'critical' | 'high' | 'medium' | 'low';
  daysUntilStockout: number | null;
  selected: boolean;
}

export interface SupplierGroup {
  supplierId: string | null;
  supplierName: string;
  leadTimeDays: number;
  minOrderValue: number;
  items: PurchaseItem[];
  totalCost: number;
  itemCount: number;
}

export function usePurchaseSuggestions() {
  const { data: restockData } = useRestockCalculations();

  return useQuery({
    queryKey: ['purchase-suggestions', restockData],
    queryFn: async () => {
      if (!restockData) return { groups: [], totalCost: 0, totalItems: 0 };

      // Get supplier details
      const { data: suppliers } = await supabase
        .from('suppliers')
        .select('id, name, default_lead_time_days, min_order_value');

      const supplierMap = new Map(suppliers?.map(s => [s.id, s]) || []);

      // Group products by supplier
      const groupMap = new Map<string | null, PurchaseItem[]>();

      restockData.products
        .filter(p => p.suggestedQuantity > 0)
        .forEach(product => {
          const key = product.supplierId;
          if (!groupMap.has(key)) {
            groupMap.set(key, []);
          }

          groupMap.get(key)!.push({
            productId: product.productId,
            productName: product.productName,
            supplierId: product.supplierId,
            supplierName: product.supplierName,
            currentStock: product.currentStock,
            suggestedQuantity: product.suggestedQuantity,
            adjustedQuantity: product.suggestedQuantity,
            unitCost: product.costPrice,
            totalCost: product.estimatedCost,
            urgency: product.urgency,
            daysUntilStockout: product.daysUntilStockout,
            selected: product.urgency === 'critical' || product.urgency === 'high',
          });
        });

      const groups: SupplierGroup[] = [];

      groupMap.forEach((items, supplierId) => {
        const supplier = supplierId ? supplierMap.get(supplierId) : null;
        
        groups.push({
          supplierId,
          supplierName: supplier?.name || 'Sem fornecedor',
          leadTimeDays: supplier?.default_lead_time_days || 7,
          minOrderValue: supplier?.min_order_value || 0,
          items: items.sort((a, b) => {
            const urgencyOrder = { critical: 0, high: 1, medium: 2, low: 3 };
            return urgencyOrder[a.urgency] - urgencyOrder[b.urgency];
          }),
          totalCost: items.reduce((sum, i) => sum + i.totalCost, 0),
          itemCount: items.length,
        });
      });

      // Sort groups by total urgency
      groups.sort((a, b) => {
        const aUrgent = a.items.filter(i => i.urgency === 'critical' || i.urgency === 'high').length;
        const bUrgent = b.items.filter(i => i.urgency === 'critical' || i.urgency === 'high').length;
        return bUrgent - aUrgent;
      });

      return {
        groups,
        totalCost: groups.reduce((sum, g) => sum + g.totalCost, 0),
        totalItems: groups.reduce((sum, g) => sum + g.itemCount, 0),
      };
    },
    enabled: !!restockData,
    staleTime: 5 * 60 * 1000,
  });
}

export function useSavePurchaseSuggestion() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (items: {
      productId: string;
      supplierId: string | null;
      suggestedQuantity: number;
      estimatedCost: number;
      urgency: 'critical' | 'high' | 'medium' | 'low';
      daysUntilStockout: number | null;
      currentStock: number;
      dailyDemand: number;
    }[]) => {
      const suggestions = items.map(item => ({
        product_id: item.productId,
        supplier_id: item.supplierId,
        suggested_quantity: item.suggestedQuantity,
        urgency: item.urgency,
        estimated_cost: item.estimatedCost,
        suggested_order_date: new Date().toISOString().split('T')[0],
        days_until_stockout: item.daysUntilStockout,
        current_stock: item.currentStock,
        daily_demand: item.dailyDemand,
        status: 'pending' as const,
      }));

      const { error } = await supabase
        .from('purchase_suggestions')
        .insert(suggestions);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['purchase-suggestions'] });
      toast.success('Sugestões de compra salvas');
    },
    onError: (error) => {
      toast.error('Erro ao salvar sugestões');
      console.error(error);
    },
  });
}

export function useMarkAsOrdered() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (productIds: string[]) => {
      const { error } = await supabase
        .from('purchase_suggestions')
        .update({ status: 'ordered' })
        .in('product_id', productIds)
        .eq('status', 'pending');

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['purchase-suggestions'] });
      toast.success('Itens marcados como pedidos');
    },
    onError: (error) => {
      toast.error('Erro ao atualizar status');
      console.error(error);
    },
  });
}
