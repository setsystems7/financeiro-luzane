import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface RestockAlert {
  id: string;
  type: 'stockout' | 'reorder' | 'excess' | 'margin' | 'trend';
  severity: 'critical' | 'warning' | 'info';
  productId: string;
  productName: string;
  message: string;
  value?: number;
  unit?: string;
  actionLabel?: string;
  createdAt: Date;
}

export function useRestockAlerts() {
  return useQuery({
    queryKey: ['restock-alerts'],
    queryFn: async () => {
      // Get products with stock info
      const { data: products, error } = await supabase
        .from('products')
        .select(`
          id,
          name,
          cost_price,
          sale_price,
          min_stock,
          product_sizes (quantity)
        `)
        .eq('is_active', true);

      if (error) throw error;

      // Get sales for demand calculation
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - 30);

      const { data: saleItems } = await supabase
        .from('sale_items')
        .select('product_id, quantity')
        .gte('created_at', startDate.toISOString());

      const demandMap = new Map<string, number>();
      saleItems?.forEach(item => {
        if (!item.product_id) return;
        demandMap.set(item.product_id, (demandMap.get(item.product_id) || 0) + item.quantity);
      });

      const alerts: RestockAlert[] = [];

      products?.forEach(product => {
        const currentStock = product.product_sizes?.reduce((sum, ps) => sum + (ps.quantity || 0), 0) || 0;
        const totalDemand = demandMap.get(product.id) || 0;
        const dailyDemand = totalDemand / 30;
        const daysUntilStockout = dailyDemand > 0 ? currentStock / dailyDemand : null;
        const margin = Number(product.sale_price) - Number(product.cost_price);
        const marginPercentage = Number(product.cost_price) > 0 
          ? (margin / Number(product.cost_price)) * 100 
          : 0;
        const daysOfCoverage = dailyDemand > 0 ? currentStock / dailyDemand : 999;

        // Stock is zero
        if (currentStock === 0 && dailyDemand > 0) {
          alerts.push({
            id: `stockout-${product.id}`,
            type: 'stockout',
            severity: 'critical',
            productId: product.id,
            productName: product.name,
            message: `Produto em ruptura! Sem estoque e com demanda de ${dailyDemand.toFixed(1)} un/dia`,
            value: 0,
            unit: 'unidades',
            actionLabel: 'Repor agora',
            createdAt: new Date(),
          });
        }
        // Stock will run out in 7 days or less
        else if (daysUntilStockout !== null && daysUntilStockout <= 7 && daysUntilStockout > 0) {
          alerts.push({
            id: `reorder-${product.id}`,
            type: 'reorder',
            severity: daysUntilStockout <= 3 ? 'critical' : 'warning',
            productId: product.id,
            productName: product.name,
            message: `Estoque acabando em ${Math.round(daysUntilStockout)} dias (${currentStock} un restantes)`,
            value: daysUntilStockout,
            unit: 'dias',
            actionLabel: 'Adicionar à lista de compras',
            createdAt: new Date(),
          });
        }

        // Excess stock (more than 90 days of coverage)
        if (daysOfCoverage > 90 && currentStock > 0) {
          alerts.push({
            id: `excess-${product.id}`,
            type: 'excess',
            severity: 'info',
            productId: product.id,
            productName: product.name,
            message: `Estoque excessivo: ${Math.round(daysOfCoverage)} dias de cobertura (${currentStock} un)`,
            value: daysOfCoverage,
            unit: 'dias',
            actionLabel: 'Considerar promoção',
            createdAt: new Date(),
          });
        }

        // Negative or very low margin
        if (marginPercentage < 10 && dailyDemand > 0) {
          alerts.push({
            id: `margin-${product.id}`,
            type: 'margin',
            severity: marginPercentage < 0 ? 'critical' : 'warning',
            productId: product.id,
            productName: product.name,
            message: `Margem ${marginPercentage < 0 ? 'negativa' : 'baixa'}: ${marginPercentage.toFixed(1)}%`,
            value: marginPercentage,
            unit: '%',
            actionLabel: 'Revisar preço',
            createdAt: new Date(),
          });
        }
      });

      // Sort by severity
      const severityOrder = { critical: 0, warning: 1, info: 2 };
      alerts.sort((a, b) => severityOrder[a.severity] - severityOrder[b.severity]);

      return alerts;
    },
    staleTime: 2 * 60 * 1000, // 2 minutes
  });
}
