import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';

export interface SaleItem {
  product_id: string | null;
  product_size_id: string | null;
  product_name: string;
  size: string | null;
  quantity: number;
  unit_price: number;
  total: number;
}

export interface CreateSaleData {
  items: SaleItem[];
  total: number;
  discount?: number;
  final_total: number; // Valor que o cliente paga (com taxa se crédito)
  base_total?: number; // Valor da peça (sem taxa) - usado para calcular líquido
  payment_method: 'dinheiro' | 'cartao_credito' | 'cartao_debito' | 'pix' | 'crediario';
  customer_name?: string;
  customer_phone?: string;
  notes?: string;
  installments?: number;
  card_brand?: string;
  card_fee_percent?: number;
}

export function useSales() {
  return useQuery({
    queryKey: ['sales'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('sales')
        .select(`
          *,
          sale_items(*)
        `)
        .order('created_at', { ascending: false })
        .limit(100);

      if (error) throw error;
      return data;
    },
  });
}

export function useTodaySales() {
  return useQuery({
    queryKey: ['sales', 'today'],
    queryFn: async () => {
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const { data, error } = await supabase
        .from('sales')
        .select('final_total')
        .gte('created_at', today.toISOString())
        .eq('status', 'concluida');

      if (error) throw error;
      
      const total = data.reduce((acc, sale) => acc + Number(sale.final_total), 0);
      return { total, count: data.length };
    },
  });
}

export function useMonthSales() {
  return useQuery({
    queryKey: ['sales', 'month'],
    queryFn: async () => {
      const startOfMonth = new Date();
      startOfMonth.setDate(1);
      startOfMonth.setHours(0, 0, 0, 0);

      const { data, error } = await supabase
        .from('sales')
        .select('final_total, total')
        .gte('created_at', startOfMonth.toISOString())
        .eq('status', 'concluida');

      if (error) throw error;
      
      const total = data.reduce((acc, sale) => acc + Number(sale.final_total), 0);
      return { total, count: data.length };
    },
  });
}

export function useMonthProfit() {
  return useQuery({
    queryKey: ['sales', 'month-profit'],
    queryFn: async () => {
      const startOfMonth = new Date();
      startOfMonth.setDate(1);
      startOfMonth.setHours(0, 0, 0, 0);

      // Get all completed sales for this month with their items
      const { data: sales, error: salesError } = await supabase
        .from('sales')
        .select(`
          id,
          final_total,
          sale_items(
            product_id,
            quantity,
            unit_price,
            total
          )
        `)
        .gte('created_at', startOfMonth.toISOString())
        .eq('status', 'concluida');

      if (salesError) throw salesError;

      // Get all products with their cost prices
      const { data: products, error: productsError } = await supabase
        .from('products')
        .select('id, cost_price');

      if (productsError) throw productsError;

      // Create a map of product costs
      const productCostMap = new Map<string, number>();
      products.forEach(p => {
        productCostMap.set(p.id, Number(p.cost_price));
      });

      // Calculate total revenue and cost
      let totalRevenue = 0;
      let totalCost = 0;

      sales.forEach(sale => {
        totalRevenue += Number(sale.final_total);
        
        sale.sale_items?.forEach((item: any) => {
          if (item.product_id) {
            const costPrice = productCostMap.get(item.product_id) || 0;
            totalCost += costPrice * item.quantity;
          }
        });
      });

      const profit = totalRevenue - totalCost;

      return { profit, totalRevenue, totalCost };
    },
  });
}

export function useCreateSale() {
  const queryClient = useQueryClient();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async (data: CreateSaleData) => {
       // Para cartão de crédito: taxa é A MAIS (cliente paga), loja recebe valor da peça
       // final_total = valor que cliente paga (com taxa)
       // base_total = valor da peça (sem taxa) = o que a loja recebe
       const cardFeePercent = data.card_fee_percent || 0;
       const baseTotal = data.base_total || data.final_total; // Valor da peça
       const cardFeeAmount = data.final_total - baseTotal; // Taxa = diferença
       const netAmount = baseTotal; // Loja recebe o valor da peça (sem taxa)

      // Create the sale
      const { data: sale, error: saleError } = await supabase
        .from('sales')
        .insert({
          user_id: user?.id || null,
          total: data.total,
          discount: data.discount || 0,
          final_total: data.final_total, // Valor que cliente pagou (com taxa)
          payment_method: data.payment_method,
          customer_name: data.customer_name || null,
          customer_phone: data.customer_phone || null,
          notes: data.notes || null,
          installments: data.installments || 1,
          status: 'concluida',
          card_brand: data.card_brand || null,
          card_fee_percent: cardFeePercent,
          card_fee_amount: cardFeeAmount,
          net_amount: netAmount, // Valor líquido = valor da peça
        })
        .select()
        .single();

      if (saleError) throw saleError;

      // Create sale items
      const saleItems = data.items.map(item => ({
        sale_id: sale.id,
        product_id: item.product_id,
        product_size_id: item.product_size_id,
        product_name: item.product_name,
        size: item.size,
        quantity: item.quantity,
        unit_price: item.unit_price,
        total: item.total,
      }));

      const { error: itemsError } = await supabase
        .from('sale_items')
        .insert(saleItems);

      if (itemsError) throw itemsError;

      // Update stock for each item
      for (const item of data.items) {
        if (item.product_size_id) {
          // Get current quantity
          const { data: sizeData } = await supabase
            .from('product_sizes')
            .select('quantity')
            .eq('id', item.product_size_id)
            .single();

          if (sizeData) {
            const newQuantity = Math.max(0, sizeData.quantity - item.quantity);
            await supabase
              .from('product_sizes')
              .update({ quantity: newQuantity })
              .eq('id', item.product_size_id);

            // Record stock movement
            await supabase
              .from('stock_movements')
              .insert({
                product_id: item.product_id,
                product_size_id: item.product_size_id,
                type: 'saida',
                quantity: item.quantity,
                notes: `Venda #${sale.sale_number}`,
                user_id: user?.id || null,
              });
          }
        }
      }

      // Create a single receivable entry for the full sale amount
      const installments = data.installments || 1;
      
      // Fee rates based on card brand and payment method
      let feeRate = (data.card_fee_percent || 0) / 100;
      
      const dueDate = new Date();
      
      // Set due date based on payment method
      if (data.payment_method === 'dinheiro' || data.payment_method === 'pix' || data.payment_method === 'cartao_credito') {
        // Immediate - today (recebe o valor total na hora, taxa é repassada ao cliente)
      } else if (data.payment_method === 'cartao_debito') {
        dueDate.setDate(dueDate.getDate() + 1);
      } else {
        // crediario: 30 days
        dueDate.setDate(dueDate.getDate() + 30);
      }
      
      // Para cartão de crédito: taxa é paga pelo cliente (A MAIS)
      // fee = taxa cobrada do cliente
      // netAmount = valor da peça (o que a loja recebe)
      const fee = cardFeeAmount; // Taxa já calculada
      
      // For cash, pix, and card payments, mark as already received (payment is immediate)
      const isImmediate = data.payment_method === 'dinheiro' || 
                         data.payment_method === 'pix' || 
                         data.payment_method === 'cartao_credito' || 
                         data.payment_method === 'cartao_debito';
      
      // Build description with installments info
      let description = `Venda #${sale.sale_number}`;
      if (installments > 1) {
        description += ` - ${installments}x`;
      }
      
      // Valor líquido = valor da peça (sem taxa) = o que entra no caixa
      const netAmountReceivable = baseTotal;
      
      const receivableEntry = {
        sale_id: sale.id,
        description: description,
        amount: data.final_total, // Valor que cliente pagou (com taxa para registro)
        fee: fee, // Taxa paga pelo cliente
        net_amount: netAmountReceivable, // Valor líquido = valor da peça (o que entra no caixa)
        due_date: dueDate.toISOString().split('T')[0],
        is_received: isImmediate,
        received_date: isImmediate ? dueDate.toISOString().split('T')[0] : null,
      };
      
      const { error: receivableError } = await supabase
        .from('receivables')
        .insert(receivableEntry);
        
      if (receivableError) {
        console.error('Error creating receivables:', receivableError);
      }

      return sale;
    },
    onSuccess: (sale) => {
      queryClient.invalidateQueries({ queryKey: ['products'] });
      queryClient.invalidateQueries({ queryKey: ['sales'] });
      queryClient.invalidateQueries({ queryKey: ['stock-movements'] });
      queryClient.invalidateQueries({ queryKey: ['receivables'] });
      toast.success(`Venda #${sale.sale_number} registrada`);
    },
    onError: (error: any) => {
      console.error('Error creating sale:', error);
      toast.error('Não foi possível finalizar a venda. Verifique os dados e tente novamente.');
    },
  });
}

export function useRecentSales(limit: number = 5) {
  return useQuery({
    queryKey: ['sales', 'recent', limit],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('sales')
        .select(`
          *,
          sale_items(product_name)
        `)
        .eq('status', 'concluida')
        .order('created_at', { ascending: false })
        .limit(limit);

      if (error) throw error;
      return data;
    },
  });
}

// Hook to get card sales with fees for reporting
export function useCardSales(startDate?: Date, endDate?: Date) {
  return useQuery({
    queryKey: ['sales', 'card-sales', startDate?.toISOString(), endDate?.toISOString()],
    queryFn: async () => {
      let query = supabase
        .from('sales')
        .select('*')
        .eq('status', 'concluida')
        .eq('payment_method', 'cartao_credito')
        .not('card_brand', 'is', null)
        .order('created_at', { ascending: false });

      if (startDate) {
        query = query.gte('created_at', startDate.toISOString());
      }
      if (endDate) {
        const endOfDay = new Date(endDate);
        endOfDay.setHours(23, 59, 59, 999);
        query = query.lte('created_at', endOfDay.toISOString());
      }

      const { data, error } = await query;
      if (error) throw error;
      
      // Calculate totals
      const totals = (data || []).reduce((acc, sale) => {
        acc.totalSales += Number(sale.final_total) || 0;
        acc.totalFees += Number(sale.card_fee_amount) || 0;
        acc.netAmount += Number(sale.net_amount) || 0;
        return acc;
      }, { totalSales: 0, totalFees: 0, netAmount: 0 });
      
      return { sales: data || [], totals };
    },
  });
}
