import { Product, Sale, StockMovement, DashboardStats } from '@/types';

export const mockProducts: Product[] = [
  {
    id: '1',
    name: 'Legging Fitness Premium',
    description: 'Legging de alta compressão com tecnologia dry-fit',
    category: 'Leggings',
    color: 'Preto',
    supplier: 'Fornecedor A',
    costPrice: 45.00,
    salePrice: 89.90,
    markup: 99.78,
    minStock: 10,
    photo: undefined,
    createdAt: new Date('2024-01-15'),
    sizes: [
      { size: 'P', quantity: 15, barcode: '7891234567001' },
      { size: 'M', quantity: 22, barcode: '7891234567002' },
      { size: 'G', quantity: 18, barcode: '7891234567003' },
      { size: 'GG', quantity: 8, barcode: '7891234567004' },
    ],
  },
  {
    id: '2',
    name: 'Top Esportivo Cross',
    description: 'Top com suporte médio para treinos intensos',
    category: 'Tops',
    color: 'Rosa',
    supplier: 'Fornecedor B',
    costPrice: 32.00,
    salePrice: 69.90,
    markup: 118.44,
    minStock: 8,
    photo: undefined,
    createdAt: new Date('2024-02-20'),
    sizes: [
      { size: 'P', quantity: 5, barcode: '7891234567011' },
      { size: 'M', quantity: 12, barcode: '7891234567012' },
      { size: 'G', quantity: 9, barcode: '7891234567013' },
    ],
  },
  {
    id: '3',
    name: 'Conjunto Yoga Flow',
    description: 'Conjunto confortável para yoga e pilates',
    category: 'Conjuntos',
    color: 'Azul Marinho',
    supplier: 'Fornecedor A',
    costPrice: 78.00,
    salePrice: 159.90,
    markup: 105.00,
    minStock: 5,
    photo: undefined,
    createdAt: new Date('2024-03-10'),
    sizes: [
      { size: 'P', quantity: 3, barcode: '7891234567021' },
      { size: 'M', quantity: 7, barcode: '7891234567022' },
      { size: 'G', quantity: 4, barcode: '7891234567023' },
      { size: 'GG', quantity: 2, barcode: '7891234567024' },
    ],
  },
  {
    id: '4',
    name: 'Short Running Pro',
    description: 'Short leve com bolso lateral para celular',
    category: 'Shorts',
    color: 'Cinza',
    supplier: 'Fornecedor C',
    costPrice: 28.00,
    salePrice: 59.90,
    markup: 113.93,
    minStock: 12,
    photo: undefined,
    createdAt: new Date('2024-03-25'),
    sizes: [
      { size: 'P', quantity: 8, barcode: '7891234567031' },
      { size: 'M', quantity: 15, barcode: '7891234567032' },
      { size: 'G', quantity: 11, barcode: '7891234567033' },
      { size: 'GG', quantity: 6, barcode: '7891234567034' },
    ],
  },
  {
    id: '5',
    name: 'Jaqueta Térmica Fit',
    description: 'Jaqueta com zíper e capuz removível',
    category: 'Jaquetas',
    color: 'Vinho',
    supplier: 'Fornecedor B',
    costPrice: 95.00,
    salePrice: 189.90,
    markup: 99.89,
    minStock: 4,
    photo: undefined,
    createdAt: new Date('2024-04-05'),
    sizes: [
      { size: 'P', quantity: 2, barcode: '7891234567041' },
      { size: 'M', quantity: 5, barcode: '7891234567042' },
      { size: 'G', quantity: 3, barcode: '7891234567043' },
    ],
  },
];

export const mockSales: Sale[] = [
  {
    id: '1',
    items: [
      { productId: '1', productName: 'Legging Fitness Premium', size: 'M', quantity: 1, unitPrice: 89.90, total: 89.90 },
      { productId: '2', productName: 'Top Esportivo Cross', size: 'M', quantity: 1, unitPrice: 69.90, total: 69.90 },
    ],
    total: 159.80,
    paymentMethod: 'Cartão Crédito',
    date: new Date(),
  },
  {
    id: '2',
    items: [
      { productId: '3', productName: 'Conjunto Yoga Flow', size: 'P', quantity: 1, unitPrice: 159.90, total: 159.90 },
    ],
    total: 159.90,
    paymentMethod: 'PIX',
    date: new Date(),
  },
];

export const mockStockMovements: StockMovement[] = [
  { id: '1', productId: '1', productName: 'Legging Fitness Premium', type: 'entrada', quantity: 50, date: new Date('2024-01-15'), notes: 'Compra inicial' },
  { id: '2', productId: '2', productName: 'Top Esportivo Cross', type: 'entrada', quantity: 30, date: new Date('2024-02-20'), notes: 'Reposição' },
  { id: '3', productId: '1', productName: 'Legging Fitness Premium', type: 'saida', quantity: 5, date: new Date('2024-03-01'), notes: 'Venda' },
];

export const mockDashboardStats: DashboardStats = {
  salesToday: 1250.00,
  salesMonth: 28750.00,
  profit: 12350.00,
  lowStockCount: 3,
  topProducts: [
    { name: 'Legging Fitness Premium', quantity: 45 },
    { name: 'Top Esportivo Cross', quantity: 32 },
    { name: 'Short Running Pro', quantity: 28 },
    { name: 'Conjunto Yoga Flow', quantity: 18 },
    { name: 'Jaqueta Térmica Fit', quantity: 12 },
  ],
};

export const categories = ['Leggings', 'Tops', 'Conjuntos', 'Shorts', 'Jaquetas', 'Acessórios'];
export const sizes = ['PP', 'P', 'M', 'G', 'GG', 'XGG'];
export const colors = ['Preto', 'Branco', 'Rosa', 'Azul Marinho', 'Cinza', 'Vinho', 'Verde', 'Coral'];
export const suppliers = ['Fornecedor A', 'Fornecedor B', 'Fornecedor C', 'Fornecedor D'];
