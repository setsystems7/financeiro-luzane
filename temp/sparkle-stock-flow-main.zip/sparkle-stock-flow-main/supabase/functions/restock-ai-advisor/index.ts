import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const systemPrompt = `Você é o **Consultor de Estoque IA**, um especialista sênior em gestão de estoque, reposição inteligente e supply chain para varejo de moda fitness. Você combina conhecimento técnico profundo com experiência prática de mercado.

## 🎯 SUA MISSÃO
Ajudar lojistas a tomar decisões estratégicas e operacionais sobre estoque, maximizando lucro e minimizando capital parado.

## 📚 SUA EXPERTISE COMPLETA

### Gestão de Estoque
- **Curva ABC**: Classificação por valor/importância (A=80% valor, B=15%, C=5%)
- **Curva XYZ**: Classificação por variabilidade de demanda
  - X: Demanda estável (CV < 20%) - previsível
  - Y: Demanda moderada (CV 20-50%) - alguma variação
  - Z: Demanda errática (CV > 50%) - imprevisível
- **Matriz ABC-XYZ**: Combinação das duas análises (9 categorias)
  - AX: Alta receita, demanda estável → PRIORIDADE MÁXIMA
  - AZ: Alta receita, demanda errática → ATENÇÃO ESPECIAL
  - CZ: Baixa receita, demanda errática → AVALIAR DESCONTINUAR

### Cálculos de Reposição
- **Ponto de Reposição (PR)**: Quando fazer novo pedido
  - Fórmula: PR = (Demanda Diária × Lead Time) + Estoque de Segurança
  - Exemplo: Se vende 5 un/dia, lead time 10 dias, ES 25 un → PR = 75 unidades

- **Estoque de Segurança (ES)**: Proteção contra variações
  - Fórmula: ES = Z × σ × √Lead Time
  - Z = 1.65 para 95% de nível de serviço
  - Z = 2.33 para 99% de nível de serviço
  - σ = desvio padrão da demanda diária

- **EOQ (Lote Econômico de Compra)**: Quantidade ideal por pedido
  - Fórmula: EOQ = √(2 × D × S / H)
  - D = Demanda anual
  - S = Custo por pedido (frete, tempo, etc.)
  - H = Custo de manutenção anual (% do valor × custo unitário)

- **Cobertura de Estoque**: Quantos dias o estoque atual dura
  - Fórmula: Cobertura = Estoque Atual / Demanda Diária
  - Ideal: 15-45 dias dependendo da categoria

- **Giro de Estoque**: Velocidade de renovação
  - Fórmula: Giro = CMV / Estoque Médio
  - Quanto maior, melhor (menos capital parado)

### Previsão de Demanda
- **Média Móvel Ponderada**: Últimos 3 meses (50%, 30%, 20%)
- **Tendência**: Crescimento ou queda nas vendas
- **Sazonalidade**: Padrões mensais/sezonais em moda fitness:
  - Janeiro/Fevereiro: ALTA (verão, resoluções de ano novo)
  - Março/Abril: MÉDIA (início de outono)
  - Maio/Junho: BAIXA (inverno, menos frequência em academias)
  - Julho/Agosto: MÉDIA-BAIXA
  - Setembro/Outubro: CRESCENTE (primavera, preparação verão)
  - Novembro/Dezembro: ALTA (Black Friday, festas, verão)

### Indicadores Financeiros
- **Capital de Giro**: Dinheiro "preso" em estoque
- **Margem de Contribuição**: Preço Venda - Custo Variável
- **Markup**: (Preço Venda - Custo) / Custo × 100
- **ROI de Estoque**: Lucro Bruto / Investimento em Estoque

### Gestão de Fornecedores
- **Lead Time**: Tempo entre pedido e recebimento
- **Pedido Mínimo**: Valor/quantidade mínima exigida
- **Score de Confiabilidade**: Histórico de entregas no prazo
- **Custo Total de Aquisição**: Preço + Frete + Impostos + Tempo

## 🎓 TERMOS TÉCNICOS (SEMPRE EXPLIQUE SE PERGUNTADO)

| Termo | Significado Simples |
|-------|---------------------|
| Lead Time | Tempo de entrega do fornecedor |
| Ruptura | Quando acaba o estoque e perde vendas |
| SKU | Código único de cada produto/tamanho |
| Giro | Quantas vezes o estoque "gira" por ano |
| Cobertura | Dias que o estoque atual dura |
| Curva ABC | Classificação por importância financeira |
| EOQ | Quantidade ideal para comprar de uma vez |
| Ponto de Reposição | Momento certo de fazer novo pedido |
| Estoque de Segurança | Reserva para imprevistos |
| CV | Coeficiente de Variação (mede previsibilidade) |

## 💡 COMO RESPONDER

### Regras de Ouro:
1. **Seja DIRETO** - Lojistas são ocupados, vá ao ponto
2. **Use NÚMEROS** - Sempre que possível, calcule
3. **Dê AÇÕES** - Não apenas diagnóstico, mas o que fazer
4. **Explique SIMPLES** - Evite jargões desnecessários
5. **Considere CAIXA** - Toda sugestão impacta o financeiro
6. **Seja HONESTO** - Se não souber, diga

### Estrutura de Resposta:
1. **Resposta direta** à pergunta
2. **Explicação** do raciocínio (se necessário)
3. **Ação recomendada** (quando aplicável)
4. **Alerta** de riscos (se houver)

### Formatação:
- Use **negrito** para termos importantes
- Use listas para organizar informações
- Use emojis com moderação para destacar pontos-chave
- Mantenha respostas concisas (máximo 3-4 parágrafos)

## 🚨 ALERTAS AUTOMÁTICOS

Quando identificar nos dados:
- ⚠️ **Ruptura iminente**: "ATENÇÃO: [Produto] pode acabar em X dias!"
- 💰 **Capital parado**: "OPORTUNIDADE: [Produto] com cobertura de X dias, considere promoção"
- 📉 **Margem negativa**: "URGENTE: [Produto] com prejuízo de R$ X por unidade"
- 🔥 **Oportunidade**: "TENDÊNCIA: [Produto] com demanda crescente"

## 🇧🇷 SEMPRE RESPONDA EM PORTUGUÊS BRASILEIRO

Mantenha tom profissional mas acessível. Você é um consultor experiente, não um robô.`;

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const body = await req.json();
    const { message, context, conversationHistory, stream = true } = body;
    
    console.log('=== RESTOCK AI ADVISOR ===');
    console.log('Message:', message);
    console.log('Stream:', stream);
    console.log('Context keys:', context ? Object.keys(context) : 'none');

    // Validate input
    if (!message || typeof message !== 'string' || message.trim().length === 0) {
      return new Response(
        JSON.stringify({ error: 'Mensagem inválida' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get API key
    let apiKey = Deno.env.get('GEMINI_API_KEY');
    let useGeminiDirect = true;
    
    if (!apiKey) {
      apiKey = Deno.env.get('LOVABLE_API_KEY');
      useGeminiDirect = false;
    }

    if (!apiKey) {
      return new Response(
        JSON.stringify({ error: 'API key não configurada' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Build context message
    let contextMessage = '';
    if (context && Object.keys(context).length > 0) {
      contextMessage = '\n\n---\n## 📊 DADOS ATUAIS DO SISTEMA\n';
      
      if (context.summary) {
        const s = context.summary;
        contextMessage += `
### Resumo Geral
| Métrica | Valor |
|---------|-------|
| Produtos Críticos | ${s.criticalProducts || 0} |
| Valor Total do Estoque | R$ ${s.totalStockValue?.toLocaleString('pt-BR', { minimumFractionDigits: 2 }) || '0,00'} |
| Cobertura Média | ${s.averageCoverage?.toFixed(1) || '0'} dias |
| Rupturas Previstas (7 dias) | ${s.predictedStockouts7Days || 0} |
`;
      }

      if (context.topCriticalProducts?.length > 0) {
        contextMessage += '\n### Produtos Críticos\n';
        context.topCriticalProducts.slice(0, 5).forEach((p: any, i: number) => {
          contextMessage += `${i + 1}. ${p.name}: ${p.currentStock} un, ${p.daysUntilStockout !== null ? `${p.daysUntilStockout} dias` : 'sem demanda'}\n`;
        });
      }

      if (context.abcSummary) {
        const abc = context.abcSummary;
        contextMessage += `\n### Curva ABC: A(${abc.classA?.count || 0}), B(${abc.classB?.count || 0}), C(${abc.classC?.count || 0})\n`;
      }
      
      contextMessage += '\n---\n';
    }

    if (stream && useGeminiDirect) {
      // STREAMING with Gemini API
      const geminiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:streamGenerateContent?alt=sse&key=${apiKey}`;
      
      // Build messages for Gemini
      const messages = [];
      if (conversationHistory && Array.isArray(conversationHistory)) {
        for (const msg of conversationHistory.slice(-10)) {
          messages.push({
            role: msg.role === 'assistant' ? 'model' : 'user',
            parts: [{ text: msg.content }]
          });
        }
      }
      
      const userMessageWithContext = contextMessage 
        ? `${message}\n\n[Contexto]${contextMessage}`
        : message;
      
      messages.push({
        role: 'user',
        parts: [{ text: userMessageWithContext }]
      });

      const geminiBody = {
        contents: messages,
        systemInstruction: { parts: [{ text: systemPrompt }] },
        generationConfig: {
          temperature: 0.7,
          maxOutputTokens: 2048,
          topP: 0.95,
        },
        safetySettings: [
          { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_NONE" },
          { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_NONE" },
          { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_NONE" },
          { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_NONE" }
        ]
      };

      console.log('Starting Gemini stream...');

      const response = await fetch(geminiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(geminiBody),
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('Gemini stream error:', response.status, errorText);
        throw new Error(`Gemini API error: ${response.status}`);
      }

      // Return the stream directly with SSE headers
      return new Response(response.body, {
        headers: {
          ...corsHeaders,
          'Content-Type': 'text/event-stream',
          'Cache-Control': 'no-cache',
          'Connection': 'keep-alive',
        },
      });

    } else if (stream && !useGeminiDirect) {
      // STREAMING with Lovable AI Gateway
      const openAIMessages = [
        { role: 'system', content: systemPrompt + contextMessage },
        ...(conversationHistory || []).slice(-10).map((m: any) => ({
          role: m.role,
          content: m.content
        })),
        { role: 'user', content: message }
      ];

      const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'google/gemini-2.5-flash',
          messages: openAIMessages,
          stream: true,
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('Lovable AI stream error:', response.status, errorText);
        
        if (response.status === 429) {
          return new Response(JSON.stringify({ error: 'Rate limit exceeded' }), {
            status: 429,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
          });
        }
        if (response.status === 402) {
          return new Response(JSON.stringify({ error: 'Credits exhausted' }), {
            status: 402,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
          });
        }
        
        throw new Error(`Lovable AI error: ${response.status}`);
      }

      return new Response(response.body, {
        headers: {
          ...corsHeaders,
          'Content-Type': 'text/event-stream',
          'Cache-Control': 'no-cache',
        },
      });

    } else {
      // NON-STREAMING (fallback)
      let aiResponse: string;

      if (useGeminiDirect) {
        const geminiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`;
        
        const messages = [];
        if (conversationHistory) {
          for (const msg of conversationHistory.slice(-10)) {
            messages.push({
              role: msg.role === 'assistant' ? 'model' : 'user',
              parts: [{ text: msg.content }]
            });
          }
        }
        messages.push({ role: 'user', parts: [{ text: contextMessage ? `${message}\n\n[Contexto]${contextMessage}` : message }] });

        const response = await fetch(geminiUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: messages,
            systemInstruction: { parts: [{ text: systemPrompt }] },
            generationConfig: { temperature: 0.7, maxOutputTokens: 2048 },
          }),
        });

        const data = await response.json();
        aiResponse = data.candidates?.[0]?.content?.parts?.[0]?.text || 'Sem resposta';
      } else {
        const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${apiKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            model: 'google/gemini-2.5-flash',
            messages: [
              { role: 'system', content: systemPrompt + contextMessage },
              ...(conversationHistory || []).slice(-10),
              { role: 'user', content: message }
            ],
          }),
        });

        const data = await response.json();
        aiResponse = data.choices?.[0]?.message?.content || 'Sem resposta';
      }

      return new Response(
        JSON.stringify({ response: aiResponse }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

  } catch (error) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
