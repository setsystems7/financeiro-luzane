-- Enable realtime for receivables table
ALTER PUBLICATION supabase_realtime ADD TABLE public.receivables;