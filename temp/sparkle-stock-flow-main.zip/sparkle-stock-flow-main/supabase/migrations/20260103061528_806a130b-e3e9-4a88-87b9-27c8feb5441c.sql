
-- Criar enum para classes ABC e XYZ
CREATE TYPE public.abc_class AS ENUM ('A', 'B', 'C');
CREATE TYPE public.xyz_class AS ENUM ('X', 'Y', 'Z');
CREATE TYPE public.urgency_level AS ENUM ('critical', 'high', 'medium', 'low');
CREATE TYPE public.suggestion_status AS ENUM ('pending', 'ordered', 'ignored');

-- Adicionar campos na tabela suppliers
ALTER TABLE public.suppliers 
ADD COLUMN IF NOT EXISTS default_lead_time_days integer DEFAULT 7,
ADD COLUMN IF NOT EXISTS order_cost numeric DEFAULT 50,
ADD COLUMN IF NOT EXISTS min_order_value numeric DEFAULT 0,
ADD COLUMN IF NOT EXISTS reliability_score integer DEFAULT 100;

-- Tabela de configurações de reposição por produto
CREATE TABLE public.restock_settings (
    id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    product_id uuid NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
    lead_time_days integer DEFAULT 7,
    safety_stock_multiplier numeric DEFAULT 1.65,
    reorder_point integer DEFAULT 0,
    economic_order_qty integer DEFAULT 0,
    abc_class abc_class DEFAULT 'C',
    xyz_class xyz_class DEFAULT 'Z',
    min_stock_override integer,
    last_calculated_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    updated_at timestamp with time zone NOT NULL DEFAULT now(),
    UNIQUE(product_id)
);

-- Tabela de previsões de demanda
CREATE TABLE public.demand_forecasts (
    id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    product_id uuid NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
    forecast_date date NOT NULL,
    predicted_daily_quantity numeric NOT NULL DEFAULT 0,
    predicted_monthly_quantity numeric NOT NULL DEFAULT 0,
    actual_quantity numeric,
    confidence_level numeric DEFAULT 0.8,
    trend_direction text DEFAULT 'stable',
    seasonality_index numeric DEFAULT 1.0,
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    UNIQUE(product_id, forecast_date)
);

-- Tabela de sugestões de compra
CREATE TABLE public.purchase_suggestions (
    id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    product_id uuid NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
    supplier_id uuid REFERENCES public.suppliers(id) ON DELETE SET NULL,
    suggested_quantity integer NOT NULL DEFAULT 0,
    urgency urgency_level DEFAULT 'medium',
    estimated_cost numeric DEFAULT 0,
    suggested_order_date date,
    days_until_stockout integer,
    current_stock integer DEFAULT 0,
    daily_demand numeric DEFAULT 0,
    status suggestion_status DEFAULT 'pending',
    notes text,
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Tabela de conversas com IA
CREATE TABLE public.ai_conversations (
    id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id uuid NOT NULL,
    title text DEFAULT 'Nova conversa',
    context_data jsonb DEFAULT '{}',
    messages jsonb DEFAULT '[]',
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.restock_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.demand_forecasts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.purchase_suggestions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ai_conversations ENABLE ROW LEVEL SECURITY;

-- Policies para restock_settings
CREATE POLICY "Authenticated users can view restock_settings"
ON public.restock_settings FOR SELECT
TO authenticated USING (true);

CREATE POLICY "Authenticated users can manage restock_settings"
ON public.restock_settings FOR ALL
TO authenticated USING (true) WITH CHECK (true);

-- Policies para demand_forecasts
CREATE POLICY "Authenticated users can view demand_forecasts"
ON public.demand_forecasts FOR SELECT
TO authenticated USING (true);

CREATE POLICY "Authenticated users can manage demand_forecasts"
ON public.demand_forecasts FOR ALL
TO authenticated USING (true) WITH CHECK (true);

-- Policies para purchase_suggestions
CREATE POLICY "Authenticated users can view purchase_suggestions"
ON public.purchase_suggestions FOR SELECT
TO authenticated USING (true);

CREATE POLICY "Authenticated users can manage purchase_suggestions"
ON public.purchase_suggestions FOR ALL
TO authenticated USING (true) WITH CHECK (true);

-- Policies para ai_conversations
CREATE POLICY "Users can view own ai_conversations"
ON public.ai_conversations FOR SELECT
TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "Users can manage own ai_conversations"
ON public.ai_conversations FOR ALL
TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Trigger para updated_at
CREATE TRIGGER update_restock_settings_updated_at
BEFORE UPDATE ON public.restock_settings
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_purchase_suggestions_updated_at
BEFORE UPDATE ON public.purchase_suggestions
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_ai_conversations_updated_at
BEFORE UPDATE ON public.ai_conversations
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Índices para performance
CREATE INDEX idx_restock_settings_product ON public.restock_settings(product_id);
CREATE INDEX idx_restock_settings_abc ON public.restock_settings(abc_class);
CREATE INDEX idx_demand_forecasts_product ON public.demand_forecasts(product_id);
CREATE INDEX idx_demand_forecasts_date ON public.demand_forecasts(forecast_date);
CREATE INDEX idx_purchase_suggestions_status ON public.purchase_suggestions(status);
CREATE INDEX idx_purchase_suggestions_urgency ON public.purchase_suggestions(urgency);
CREATE INDEX idx_ai_conversations_user ON public.ai_conversations(user_id);
