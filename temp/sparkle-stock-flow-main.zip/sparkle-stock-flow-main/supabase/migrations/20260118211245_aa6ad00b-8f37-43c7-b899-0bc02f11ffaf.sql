
-- Create fiado_sales table for credit sales
CREATE TABLE public.fiado_sales (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  customer_name TEXT NOT NULL,
  customer_phone TEXT,
  customer_cpf TEXT,
  total NUMERIC NOT NULL DEFAULT 0,
  amount_paid NUMERIC NOT NULL DEFAULT 0,
  amount_pending NUMERIC NOT NULL DEFAULT 0,
  installments INTEGER NOT NULL DEFAULT 1,
  status TEXT NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente', 'aprovado', 'pago', 'cancelado')),
  approved_at TIMESTAMP WITH TIME ZONE,
  approved_by UUID,
  notes TEXT,
  user_id UUID,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create fiado_sale_items table
CREATE TABLE public.fiado_sale_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  fiado_sale_id UUID NOT NULL REFERENCES public.fiado_sales(id) ON DELETE CASCADE,
  product_id UUID,
  product_size_id UUID,
  product_name TEXT NOT NULL,
  size TEXT,
  quantity INTEGER NOT NULL,
  unit_price NUMERIC NOT NULL,
  total NUMERIC NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create fiado_payments table for partial payments
CREATE TABLE public.fiado_payments (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  fiado_sale_id UUID NOT NULL REFERENCES public.fiado_sales(id) ON DELETE CASCADE,
  amount NUMERIC NOT NULL,
  payment_method TEXT DEFAULT 'dinheiro',
  notes TEXT,
  user_id UUID,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.fiado_sales ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.fiado_sale_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.fiado_payments ENABLE ROW LEVEL SECURITY;

-- RLS Policies for fiado_sales
CREATE POLICY "Authenticated users can view fiado_sales"
ON public.fiado_sales FOR SELECT
USING (true);

CREATE POLICY "Authenticated users can manage fiado_sales"
ON public.fiado_sales FOR ALL
USING (true)
WITH CHECK (true);

-- RLS Policies for fiado_sale_items
CREATE POLICY "Authenticated users can view fiado_sale_items"
ON public.fiado_sale_items FOR SELECT
USING (true);

CREATE POLICY "Authenticated users can manage fiado_sale_items"
ON public.fiado_sale_items FOR ALL
USING (true)
WITH CHECK (true);

-- RLS Policies for fiado_payments
CREATE POLICY "Authenticated users can view fiado_payments"
ON public.fiado_payments FOR SELECT
USING (true);

CREATE POLICY "Authenticated users can manage fiado_payments"
ON public.fiado_payments FOR ALL
USING (true)
WITH CHECK (true);

-- Create trigger for updated_at on fiado_sales
CREATE TRIGGER update_fiado_sales_updated_at
BEFORE UPDATE ON public.fiado_sales
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Create indexes for better performance
CREATE INDEX idx_fiado_sales_status ON public.fiado_sales(status);
CREATE INDEX idx_fiado_sales_customer_name ON public.fiado_sales(customer_name);
CREATE INDEX idx_fiado_sale_items_fiado_sale_id ON public.fiado_sale_items(fiado_sale_id);
CREATE INDEX idx_fiado_payments_fiado_sale_id ON public.fiado_payments(fiado_sale_id);
