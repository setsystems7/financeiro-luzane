-- Add card brand and fee columns to sales table for tracking credit/debit card sales
ALTER TABLE public.sales 
ADD COLUMN card_brand TEXT,
ADD COLUMN card_fee_percent NUMERIC DEFAULT 0,
ADD COLUMN card_fee_amount NUMERIC DEFAULT 0,
ADD COLUMN net_amount NUMERIC;

-- Update existing sales to set net_amount = final_total where it's null
UPDATE public.sales SET net_amount = final_total WHERE net_amount IS NULL;